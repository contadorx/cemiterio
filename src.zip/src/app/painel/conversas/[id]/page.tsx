"use client";

import { useEffect, useRef, useState } from "react";
import { useParams } from "next/navigation";
import { PainelNav, painel, cor } from "../../ui";

export default function Thread() {
  const params = useParams();
  const id = params?.id as string;
  const [d, setD] = useState<any>(null);
  const [texto, setTexto] = useState("");
  const [rascText, setRascText] = useState("");
  const [ocupado, setOcupado] = useState(false);
  const fim = useRef<HTMLDivElement>(null);

  async function carregar() {
    const r = await fetch(`/api/conversas/${id}`).then((x) => x.json());
    if (r.ok) {
      setD(r);
      setRascText(r.rascunho?.rascunho || "");
    }
  }
  useEffect(() => {
    if (id) carregar();
  }, [id]);
  useEffect(() => {
    fim.current?.scrollIntoView();
  }, [d]);

  async function enviar() {
    if (!texto.trim()) return;
    setOcupado(true);
    await fetch(`/api/conversas/${id}/enviar`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ texto }),
    });
    setTexto("");
    setOcupado(false);
    carregar();
  }

  async function agirRascunho(acao: "aprovou" | "editou" | "descartou") {
    setOcupado(true);
    await fetch("/api/atendimento/aprovar", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ interacaoId: d.rascunho.id, acao, textoFinal: acao === "editou" ? rascText : undefined }),
    });
    setOcupado(false);
    carregar();
  }

  async function alternarIa() {
    setOcupado(true);
    await fetch(`/api/conversas/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ escalada_humano: !d.conversa.escalada }),
    });
    setOcupado(false);
    carregar();
  }

  if (!d) {
    return (
      <div style={painel.wrap}>
        <PainelNav atual="/painel/conversas" />
        <div style={painel.conteudo}><p style={{ color: cor.cinza }}>Carregando…</p></div>
      </div>
    );
  }

  return (
    <div style={painel.wrap}>
      <PainelNav atual="/painel/conversas" />
      <div style={painel.conteudo}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h1 style={painel.h1}>{d.conversa.cliente}</h1>
          <button style={d.conversa.escalada ? painel.botao : painel.botaoSec} onClick={alternarIa} disabled={ocupado}>
            {d.conversa.escalada ? "Devolver para a IA" : "Assumir conversa"}
          </button>
        </div>
        <p style={{ color: cor.cinza, marginTop: -10, fontSize: 14 }}>
          {d.conversa.escalada ? "Você está atendendo — a IA não responde." : "A IA está atendendo (rascunhos aparecem aqui)."}
        </p>

        <div style={{ ...painel.card, maxHeight: 420, overflowY: "auto" }}>
          {d.mensagens.length === 0 && <p style={{ color: cor.cinza }}>Sem mensagens ainda.</p>}
          {(d.mensagens || []).map((m: any, i: number) => (
            <div key={i} style={{ margin: "8px 0", textAlign: m.autor === "cliente" ? "left" : "right" }}>
              <span style={{ display: "inline-block", maxWidth: "80%", padding: "8px 12px", borderRadius: 12, background: m.autor === "cliente" ? "#e2e8f0" : m.autor === "ia" ? "#0f766e" : "#1e293b", color: m.autor === "cliente" ? cor.navy : "#fff", fontSize: 14 }}>
                {m.transcrita && (
                <span style={{ display: "block", fontSize: 15, color: cor.cinza,
                               marginBottom: 4, fontStyle: "italic" }}>
                  🎤 áudio transcrito
                </span>
              )}
              {m.texto}
                <div style={{ fontSize: 10, opacity: 0.7, marginTop: 2 }}>{m.autor}</div>
              </span>
            </div>
          ))}
          <div ref={fim} />
        </div>

        {d.rascunho && (
          <div style={{ ...painel.card, borderColor: "#fbbf24", background: "#fffbeb" }}>
            <div style={painel.rotulo}>Rascunho da IA — revise antes de enviar</div>
            {d.rascunho.motivo_retencao && (
              <p style={{ fontSize: 15, color: "#92400e", margin: "0 0 8px" }}>
                Não foi automático porque: {d.rascunho.motivo_retencao}
              </p>
            )}
            <textarea
              style={{ ...painel.input, minHeight: 160, resize: "vertical", fontFamily: "inherit" }}
              value={rascText}
              onChange={(e) => setRascText(e.target.value)}
            />
            <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
              <button style={painel.botao} disabled={ocupado} onClick={() => agirRascunho("aprovou")}>Aprovar e enviar</button>
              <button style={painel.botaoSec} disabled={ocupado} onClick={() => agirRascunho("editou")}>Enviar editado</button>
              <button style={painel.botaoPerigo} disabled={ocupado} onClick={() => agirRascunho("descartou")}>Descartar</button>
            </div>
          </div>
        )}

        <div>
          <textarea
            rows={5}
            style={{ ...painel.input, width: "100%", minHeight: 130, resize: "vertical",
                     fontFamily: "inherit", lineHeight: 1.5 }}
            placeholder="Escreva uma mensagem…"
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
            onKeyDown={(e) => {
              // Enter quebra linha (mensagem longa é normal aqui).
              // Ctrl+Enter ou Cmd+Enter envia.
              if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) enviar();
            }}
          />
          <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 8, flexWrap: "wrap" }}>
            <button style={painel.botao} onClick={enviar} disabled={ocupado || !texto.trim()}>
              Enviar
            </button>
            <span style={{ fontSize: 14, color: cor.cinza }}>
              Enter quebra linha · Ctrl+Enter envia
            </span>
          </div>
        </div>
        <MeAjuda conversaId={id} onEscolher={(t) => setTexto(t)} />
      </div>
    </div>
  );
}


/**
 * "Me ajuda a escrever" — você dá o contexto e o tom; a IA devolve três
 * caminhos diferentes. Escolhe um, ajusta e manda. Nada sai sozinho.
 */
function MeAjuda({ conversaId, onEscolher }: { conversaId: string; onEscolher: (t: string) => void }) {
  const [aberto, setAberto] = useState(false);
  const [contexto, setContexto] = useState("");
  const [tom, setTom] = useState("acolhedor");
  const [opcoes, setOpcoes] = useState<any[]>([]);
  const [pensando, setPensando] = useState(false);
  const [copiado, setCopiado] = useState<number | null>(null);

  /** Edita uma sugestão no lugar, guardando o texto original para poder desfazer. */
  function trocarTexto(i: number, texto: string) {
    setOpcoes((atual) =>
      atual.map((o, idx) => (idx === i ? { ...o, texto } : o))
    );
  }

  async function pedir() {
    setPensando(true);
    setOpcoes([]);
    const r = await fetch(`/api/conversas/${conversaId}/ajuda`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contexto, tom }),
    }).then((x) => x.json()).catch(() => null);
    setPensando(false);
    if (r?.ok) {
      // guarda o texto como veio, para o "desfazer edição"
      setOpcoes((r.opcoes || []).map((o: any) => ({ ...o, original: o.texto })));
    }
    else alert(r?.erro === "teto_ia_atingido" ? "Teto de IA do dia atingido." : "Não consegui sugerir agora.");
  }

  if (!aberto) {
    return (
      <button style={{ ...painel.botaoSec, marginBottom: 12 }} onClick={() => setAberto(true)}>
        ✍️ Me ajuda a escrever
      </button>
    );
  }

  return (
    <div style={{ ...painel.card, borderLeft: `4px solid ${cor.teal}`, background: "#f0fdfa" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <strong style={{ color: cor.navy }}>Me ajuda a escrever</strong>
        <button style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer",
                         color: cor.cinza }} onClick={() => setAberto(false)}>✕</button>
      </div>

      <div style={{ marginTop: 10 }}>
        <label style={painel.rotulo}>
          O que você quer dizer? (quanto mais contexto, melhor a sugestão)
        </label>
        <textarea
          style={{ ...painel.input, minHeight: 160, fontFamily: "inherit" }}
          value={contexto}
          onChange={(e) => setContexto(e.target.value)}
          placeholder="Ex.: ela perguntou se dá para adiar a limpeza de novembro. Dá sim, mas quero aproveitar para combinar o Finados. Ela é antiga de casa e sempre paga certinho."
        />
      </div>

      <div style={{ display: "flex", gap: 8, alignItems: "flex-end", flexWrap: "wrap", marginTop: 10 }}>
        <div>
          <label style={painel.rotulo}>Tom</label>
          <select style={{ ...painel.input, width: 150 }} value={tom} onChange={(e) => setTom(e.target.value)}>
            <option value="acolhedor">Acolhedor</option>
            <option value="objetivo">Objetivo</option>
            <option value="firme">Firme</option>
          </select>
        </div>
        <button style={painel.botao} onClick={pedir} disabled={pensando}>
          {pensando ? "Pensando…" : opcoes.length ? "Sugerir de novo" : "Sugerir 3 caminhos"}
        </button>
      </div>

      {opcoes.map((o, i) => (
        <div key={i} style={{ background: "#fff", border: `1px solid ${cor.linha}`,
                              borderRadius: 10, padding: 12, marginTop: 10 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center",
                        gap: 8, flexWrap: "wrap" }}>
            <div style={{ fontSize: 14, color: cor.teal, textTransform: "uppercase",
                          letterSpacing: 0.5, fontWeight: 700 }}>
              {o.titulo || `Opção ${i + 1}`}
            </div>
            {o.texto !== (o.original ?? o.texto) && (
              <button
                style={{ background: "none", border: "none", color: cor.cinza, fontSize: 13,
                         cursor: "pointer", textDecoration: "underline" }}
                onClick={() => trocarTexto(i, o.original)}
              >
                desfazer edição
              </button>
            )}
          </div>

          {/* editável aqui mesmo: dá para ajustar antes de escolher */}
          <textarea
            style={{ ...painel.input, minHeight: 130, marginTop: 8, fontFamily: "inherit",
                     lineHeight: 1.5, resize: "vertical" }}
            value={o.texto}
            onChange={(e) => trocarTexto(i, e.target.value)}
          />

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8, alignItems: "center" }}>
            <button style={painel.botao}
                    onClick={() => { onEscolher(o.texto); setAberto(false); }}>
              Usar esta
            </button>
            <button style={painel.botaoSec}
                    onClick={() => { navigator.clipboard?.writeText(o.texto); setCopiado(i);
                                     setTimeout(() => setCopiado(null), 1500); }}>
              {copiado === i ? "✓ copiado" : "Copiar"}
            </button>
            <span style={{ fontSize: 13, color: cor.cinza }}>
              {o.texto.trim().split(/\s+/).filter(Boolean).length} palavras
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
