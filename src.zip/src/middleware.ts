import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";

const PROTEGIDAS = ["/campo", "/painel"];

export async function middleware(req: NextRequest) {
  // A home virou o site publico do Zelo & Memoria. Sem esta saida antecipada,
  // TODA visita de familia dispararia uma checagem de sessao no Supabase antes
  // de a pagina aparecer: ida e volta de rede pura, num visitante que nunca vai
  // ter login. So /painel e /campo precisam saber quem esta logado.
  if (!PROTEGIDAS.some((p) => req.nextUrl.pathname.startsWith(p))) {
    return NextResponse.next({ request: req });
  }

  let res = NextResponse.next({ request: req });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => req.cookies.getAll(),
        setAll: (list: { name: string; value: string; options?: any }[]) => {
          list.forEach(({ name, value }) => req.cookies.set(name, value));
          res = NextResponse.next({ request: req });
          list.forEach(({ name, value, options }) => res.cookies.set(name, value, options));
        },
      },
    }
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = req.nextUrl.pathname;
  const precisaLogin = PROTEGIDAS.some((p) => path.startsWith(p));

  if (precisaLogin && !user) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("redir", path);
    return NextResponse.redirect(url);
  }

  // G1: papel 'campo' não acessa o painel do dono
  if (user && path.startsWith("/painel")) {
    // filtrar por user_id e obrigatorio: sem isso o limit(1) pode trazer a linha
    // da ajudante e chutar o dono do painel para /campo.
    const { data: membro } = await supabase
      .from("membros")
      .select("papel")
      .eq("user_id", user.id)
      .maybeSingle();
    if ((membro as any)?.papel === "campo") {
      const url = req.nextUrl.clone();
      url.pathname = "/campo";
      url.search = "";
      return NextResponse.redirect(url);
    }
  }

  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|api).*)"],
};
