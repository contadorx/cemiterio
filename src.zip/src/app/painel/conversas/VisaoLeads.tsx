"use client";

/**
 * O antigo /painel/leads, agora ABA da central de Atendimento.
 * Nada da tela mudou. /painel/leads redireciona para ca.
 */

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { painel, cor } from "../ui";
import { useConfirmar, useRecado, type Pedido } from "@/components/Dialogos";

/**
 * LEADS — duas naturezas bem diferentes:
 *  · quem ESCREVEU no WhatsApp e não é cliente (a IA não responde: pode ser
 *    alguém da vida pessoal da Sureya)
 *  · quem a Sureya QUER abordar (prospecção, com o contexto que ela conhece)
 */
export default function VisaoLeads() {
  const recado = useRecado();
  const perguntar = useConfirmar();
  const [lista, setLista] = useState<any[]>([]);
  const [f, setF] = useState({ status: "", origem: "", ocultos: false });
  const [novo, setNovo] = useState(false);
  const [carregando, setCarregando] = useState(true);
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [emMassa, setEmMassa] = useState(false);

  const carregar = useCallback(async () => {
    setCarregando(true);
    const p = new URLSearchParams();
    if (f.status) p.set("status", f.status);
    if (f.origem) p.set("origem", f.origem);
    if (f.ocultos) p.set("ocultos", "1");
    const r = await fetch(`/api/leads?${p}`).then((x) => x.json()).catch(() => null);
    const leads = r?.leads || [];
    setLista(leads);
    const presentes = new Set(leads.map((l: any) => l.id));
    setSel((prev) => new Set([...prev].filter((id) => presentes.has(id))));
    setCarregando(false);
  }, [f]);

  useEffect(() => { carregar(); }, [carregar]);

  const todasMarcadas = lista.length > 0 && lista.every((l) => sel.has(l.id));
  function alternarUma(id: string) {
    setSel((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }
  function alternarTodas() {
    setSel(todasMarcadas ? new Set() : new Set(lista.map((l) => l.id)));
  }
  async function acaoMassa(acao: string, confirmar?: Pedido) {
    const ids = [...sel];
    if (!ids.length) return;
    if (confirmar && !await perguntar({
      oQue: confirmar.oQue, efeito: confirmar.efeito,
      confirmar: confirmar.confirmar, tom: confirmar.tom,
    })) return;
    setEmMassa(true);
    const r = await fetch("/api/leads/acao-massa", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids, acao }),
    }).then((x) => x.json()).catch(() => null);
    setEmMassa(false);
    if (r?.ok) {
      if (acao === "converter" && r.falhas) recado.aviso(`${r.criados} convertido(s). ${r.falhas} não deu (ex.: telefone já é cliente).`);
      setSel(new Set()); carregar();
    } else recado.erro("Falhou: " + (r?.erro || "erro"));
  }

  return (
    <div>
      <div>

        <div style={{ ...painel.card, borderLeft: `4px solid ${cor.navy}`, background: "#f8fafc" }}>
          <p style={{ margin: 0, fontSize: 14, color: cor.cinza, lineHeight: 1.6 }}>
            O WhatsApp é o número pessoal da Sureya, então <b>a IA nunca responde sozinha</b> a
            quem não é cliente — pode ser uma amiga, um parente ou alguém do outro trabalho.
            Quem escreve aparece aqui para ela decidir. Para abordar alguém, cadastre com o
            contexto que você conhece e peça uma sugestão de mensagem.
          </p>
        </div>

        <div style={{ ...painel.card, padding: 12 }}>
          <div data-filtros style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <select style={{ ...painel.input, width: "auto" }} value={f.origem}
                    onChange={(e) => setF({ ...f, origem: e.target.value })}>
              <option value="">Todas as origens</option>
              <option value="whatsapp">Escreveram no WhatsApp</option>
              <option value="manual">Prospecção (cadastrei eu)</option>
              <option value="indicacao">Indicação</option>
            </select>
            <select style={{ ...painel.input, width: "auto" }} value={f.status}
                    onChange={(e) => setF({ ...f, status: e.target.value })}>
              <option value="">Ativos (esconde descartados)</option>
              <option value="novo">Novos</option>
              <option value="em_conversa">Em conversa</option>
              <option value="convertido">Viraram cliente</option>
              <option value="descartado">Descartados</option>
            </select>
            <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 15, color: cor.cinza }}>
              <input type="checkbox" checked={f.ocultos}
                     onChange={(e) => setF({ ...f, ocultos: e.target.checked })} />
              mostrar ignorados
            </label>
            <button style={{ ...painel.botao, marginLeft: "auto" }} onClick={() => setNovo(!novo)}>
              {novo ? "Fechar" : "+ Nova prospecção"}
            </button>
          </div>
        </div>

        {novo && <NovoLead onPronto={() => { setNovo(false); carregar(); }} />}

        {/* seleção em lote */}
        {lista.length > 0 && (
          <div style={{
            position: "sticky", top: 0, zIndex: 5, marginBottom: 12,
            display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap",
            background: sel.size > 0 ? cor.navy : "#fff",
            color: sel.size > 0 ? "#fff" : cor.navy,
            border: `1px solid ${sel.size > 0 ? cor.navy : cor.linha}`,
            borderRadius: 12, padding: "10px 14px",
          }}>
            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 15 }}>
              <input type="checkbox" checked={todasMarcadas} onChange={alternarTodas} style={{ width: 18, height: 18 }} />
              {sel.size > 0 ? `${sel.size} selecionado(s)` : "Selecionar todos"}
            </label>
            {sel.size > 0 && (
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginLeft: "auto" }}>
                <button style={painel.botaoMini} disabled={emMassa}
                        onClick={() => acaoMassa("converter", {
                          oQue: `Transformar ${sel.size} lead(s) em cliente?`,
                          efeito: "Cada um cria uma ficha, que você completa depois. A conversa vai junto.",
                          confirmar: "Transformar",
                        })}>
                  Transformar em cliente
                </button>
                <button style={painel.botaoMiniSec} disabled={emMassa}
                        onClick={() => acaoMassa("em_conversa")}>Em conversa</button>
                <button style={painel.botaoMiniSec} disabled={emMassa}
                        onClick={() => acaoMassa("descartar", {
                          oQue: `Descartar ${sel.size} lead(s)?`,
                          efeito: "Somem da lista ativa. Voltam se a pessoa escrever de novo.",
                          confirmar: "Descartar", tom: "perigo",
                        })}>Descartar</button>
                <button style={painel.botaoMiniPerigo} disabled={emMassa}
                        onClick={() => acaoMassa("nao_eh_lead", {
                          oQue: `Marcar ${sel.size} como "não é lead"?`,
                          efeito: "Os números entram na lista de bloqueio e não voltam a aparecer nem se escreverem de novo.",
                          confirmar: "Não são leads", tom: "perigo",
                        })}>
                  🚫 Não é lead
                </button>
                <button style={{ ...painel.botaoMiniSec, background: "transparent", color: "#fff", borderColor: "rgba(255,255,255,.4)" }}
                        disabled={emMassa} onClick={() => setSel(new Set())}>Limpar</button>
              </div>
            )}
          </div>
        )}

        {carregando && <p style={{ color: cor.cinza }}>Carregando…</p>}
        {!carregando && lista.length === 0 && (
          <div style={painel.card}><p style={{ margin: 0, color: cor.cinza }}>Nenhum lead com esses filtros.</p></div>
        )}

        {lista.map((l) => (
          <Lead key={l.id} l={l} onMudou={carregar}
                marcado={sel.has(l.id)} onMarcar={() => alternarUma(l.id)} />
        ))}
      </div>
    </div>
  );
}

function NovoLead({ onPronto }: { onPronto: () => void }) {
  const recado = useRecado();
  const [f, setF] = useState({ nome: "", telefone: "", contexto: "", jazigoRef: "", proximoPasso: "" });
  const [salvando, setSalvando] = useState(false);

  async function salvar() {
    setSalvando(true);
    const r = await fetch("/api/leads", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f),
    }).then((x) => x.json()).catch(() => null);
    setSalvando(false);
    if (r?.ok) onPronto();
    else recado.erro("Falhou: " + (r?.erro || "erro"));
  }

  return (
    <div style={painel.card}>
      <strong style={{ color: cor.navy }}>Quem você quer abordar?</strong>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}>
        <div style={{ flex: 1, minWidth: 180 }}>
          <label style={painel.rotulo}>Nome</label>
          <input style={painel.input} value={f.nome} onChange={(e) => setF({ ...f, nome: e.target.value })} />
        </div>
        <div>
          <label style={painel.rotulo}>WhatsApp</label>
          <input style={{ ...painel.input, width: 170 }} value={f.telefone}
                 onChange={(e) => setF({ ...f, telefone: e.target.value })} placeholder="11 99999-9999" />
        </div>
        <div style={{ minWidth: 160 }}>
          <label style={painel.rotulo}>Jazigo de interesse</label>
          <input style={painel.input} value={f.jazigoRef}
                 onChange={(e) => setF({ ...f, jazigoRef: e.target.value })} placeholder="Família SILVA · QD 1" />
        </div>
      </div>
      <div style={{ marginTop: 10 }}>
        <label style={painel.rotulo}>
          O que você sabe sobre a pessoa (é isto que a IA usa para escrever)
        </label>
        <textarea style={{ ...painel.input, minHeight: 70, fontFamily: "inherit" }} value={f.contexto}
                  onChange={(e) => setF({ ...f, contexto: e.target.value })}
                  placeholder="Ex.: irmã da dona Cecília, que indicou. O jazigo do pai está sem cuidado há uns 2 anos. Falei com ela no cemitério em maio." />
      </div>
      <button style={{ ...painel.botao, marginTop: 12 }} onClick={salvar} disabled={salvando}>
        {salvando ? "Salvando…" : "Cadastrar"}
      </button>
    </div>
  );
}

function Lead({ l, onMudou, marcado, onMarcar }: {
  l: any; onMudou: () => void; marcado: boolean; onMarcar: () => void;
}) {
  const perguntar = useConfirmar();
  const recado = useRecado();
  const [sugestao, setSugestao] = useState("");
  const [pensando, setPensando] = useState(false);
  const [copiado, setCopiado] = useState(false);
  const [ocupado, setOcupado] = useState(false);

  const msgs = Array.isArray(l.mensagens) ? l.mensagens : [];
  const doWhats = l.origem === "whatsapp";
  const convertido = l.status === "convertido" || !!l.cliente_id;

  async function converter() {
    if (!await perguntar({
      oQue: `Transformar ${l.nome || l.nome_wa || l.telefone} em cliente?`,
      efeito: "A conversa vai junto e você completa a ficha depois.",
      confirmar: "Transformar em cliente",
    })) return;
    setOcupado(true);
    const r = await fetch(`/api/leads/${l.id}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ acao: "converter" }),
    }).then((x) => x.json()).catch(() => null);
    setOcupado(false);
    if (r?.ok && r.clienteId) location.href = `/painel/clientes/${r.clienteId}`;
    else recado.erro("Não consegui converter: " + (r?.erro || "erro"));
  }

  async function sugerir() {
    setPensando(true);
    const r = await fetch(`/api/leads/${l.id}/abordagem`, { method: "POST" })
      .then((x) => x.json()).catch(() => null);
    setPensando(false);
    if (r?.ok) setSugestao(r.texto);
    else recado.erro(r?.erro === "teto_ia_atingido" ? "Teto de IA do dia atingido." : "Não consegui sugerir agora.");
  }

  async function mudarStatus(status: string) {
    const r = await fetch(`/api/leads/${l.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    }).then((x) => x.json()).catch(() => null);
    if (r?.ok) onMudou(); else recado.erro("Não consegui atualizar.");
  }

  /** Não é cliente e não vai ser: some da lista e não volta nem escrevendo de novo. */
  async function naoEhLead() {
    const r0 = await perguntar({
      oQue: `Marcar ${l.nome || l.nome_wa || l.telefone} como "não é lead"?`,
      efeito: "Some da lista e o número não volta a aparecer nem se escrever de novo.",
      confirmar: "Não é lead", tom: "perigo",
      pedirMotivo: "Motivo (opcional)", motivoOpcional: true,
    });
    if (!r0) return;
    const motivo = r0 === true ? "" : r0.motivo;
    const r = await fetch(`/api/leads/${l.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ignorado: true, motivoIgnorado: motivo || null }),
    }).then((x) => x.json()).catch(() => null);
    if (r?.ok) onMudou(); else recado.erro("Não consegui marcar.");
  }

  async function voltarASerLead() {
    const r = await fetch(`/api/leads/${l.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ignorado: false, status: "novo" }),
    }).then((x) => x.json()).catch(() => null);
    if (r?.ok) onMudou();
  }

  const tel = String(l.telefone || "").replace(/\D/g, "");
  const linkWhats = `https://wa.me/${tel}${sugestao ? `?text=${encodeURIComponent(sugestao)}` : ""}`;

  return (
    <div style={{ ...painel.card,
      background: marcado ? "#eef2ff" : "#fff",
      outline: marcado ? `2px solid ${cor.navy}` : "none",
      borderLeft: doWhats ? "4px solid #d97706" : `4px solid ${cor.teal}` }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
        <input type="checkbox" checked={marcado} onChange={onMarcar}
               aria-label={`Selecionar ${l.nome || l.nome_wa || l.telefone}`}
               style={{ width: 18, height: 18, marginTop: 4, flexShrink: 0, cursor: "pointer" }} />
        <div style={{ flex: 1, minWidth: 200 }}>
          <Link href={`/painel/leads/${l.id}`} style={{ textDecoration: "none" }}>
            <strong style={{ color: cor.navy, fontSize: 16 }}>
              {l.nome || l.nome_wa || "Sem nome"}
            </strong>
          </Link>
          <div style={{ fontSize: 15, color: cor.cinza, marginTop: 2 }}>
            {l.telefone} · {doWhats ? "escreveu no WhatsApp" : l.origem === "manual" ? "prospecção" : l.origem}
            {" · "}{l.status}
            {l.ignorado && (
              <span style={{ color: "#b91c1c", fontWeight: 600 }}>
                {" · "}🚫 não é lead{l.motivo_ignorado ? ` (${l.motivo_ignorado})` : ""}
              </span>
            )}
          </div>
          {l.jazigo_ref && <div style={{ fontSize: 15, color: cor.cinza }}>Jazigo: {l.jazigo_ref}</div>}
          {l.contexto && (
            <p style={{ fontSize: 14, color: "#334155", margin: "8px 0 0", background: "#f8fafc",
                        padding: 10, borderRadius: 8 }}>{l.contexto}</p>
          )}
          {msgs.length > 0 && (
            <div style={{ marginTop: 8 }}>
              <div style={{ fontSize: 14, color: cor.cinza, textTransform: "uppercase" }}>O que escreveu:</div>
              {msgs.slice(-3).map((m: any, i: number) => (
                <p key={i} style={{ fontSize: 14, margin: "4px 0", color: "#334155" }}>“{m.texto}”</p>
              ))}
            </div>
          )}
        </div>
      </div>

      {sugestao && (
        <div style={{ marginTop: 12, padding: 12, background: "#f0fdfa", borderRadius: 10,
                      border: `1px solid ${cor.teal}` }}>
          <div style={{ fontSize: 14, color: cor.teal, textTransform: "uppercase", marginBottom: 6 }}>
            Sugestão — leia e ajuste antes de mandar
          </div>
          <textarea style={{ ...painel.input, minHeight: 150, fontFamily: "inherit",
                             lineHeight: 1.5, resize: "vertical" }}
                    value={sugestao} onChange={(e) => setSugestao(e.target.value)} />
          <div style={{ fontSize: 13, color: cor.cinza, marginTop: 6 }}>
            {sugestao.trim().split(/\s+/).filter(Boolean).length} palavras · edite à vontade antes de mandar
          </div>
        </div>
      )}

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}>
        <Link href={`/painel/leads/${l.id}`} style={painel.botao}>Abrir conversa</Link>
        {!convertido && (
          <button style={painel.botaoSec} onClick={converter} disabled={ocupado}>Transformar em cliente</button>
        )}
        {convertido && l.cliente_id && (
          <Link href={`/painel/clientes/${l.cliente_id}`} style={painel.botaoSec}>Abrir ficha do cliente</Link>
        )}
        <button style={painel.botaoSec} onClick={sugerir} disabled={pensando}>
          {pensando ? "Pensando…" : sugestao ? "Sugerir outra" : "✨ Sugerir mensagem"}
        </button>
        {sugestao && (
          <button style={painel.botaoSec} onClick={() => {
            navigator.clipboard?.writeText(sugestao); setCopiado(true); setTimeout(() => setCopiado(false), 1500);
          }}>{copiado ? "✓ copiado" : "Copiar"}</button>
        )}
        <a href={linkWhats} target="_blank" rel="noreferrer" style={painel.botaoSec}>Abrir no WhatsApp</a>
        {!convertido && l.status !== "em_conversa" && (
          <button style={painel.botaoSec} onClick={() => mudarStatus("em_conversa")}>Em conversa</button>
        )}
        {!l.ignorado && (
          <>
            <button style={painel.botaoSec} onClick={() => mudarStatus("descartado")}>
              Descartar
            </button>
            <button style={painel.botaoSec} onClick={naoEhLead}>
              🚫 Não é lead
            </button>
          </>
        )}
        {l.ignorado && (
          <button style={painel.botaoSec} onClick={voltarASerLead}>
            Voltar a mostrar
          </button>
        )}
      </div>
    </div>
  );
}
