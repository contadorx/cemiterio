"use client";

import Link from "next/link";
import { MARCA } from "@/lib/marca";
import { useState, useEffect } from "react";
import { ALVO, ALVO_MINI, ALVO_CAMPO, RAIO_CARTAO, RAIO_CONTROLE,
         PAD_CARTAO, GAP_CARTAO, TEXTO_CONTROLE } from "./medidas";

/**
 * As cores agora vêm dos TOKENS (app/tema.css), e não de hex cravado.
 *
 * Por que reapontar em vez de reescrever as telas: cinco telas ainda usam
 * estes objetos de estilo — Famílias, Agenda, Avulsos, Financeiro e Config,
 * mais de 2.300 linhas somadas. Reescrever tudo à mão arriscaria perder
 * função. Trocando a origem da cor aqui, todas passam a falar a mesma língua
 * visual do resto do sistema, e o tema escuro alcança elas de graça.
 *
 * Conforme cada tela for reescrita com `pecas.tsx`, some daqui.
 */
export const cor = {
  navy: "rgb(var(--zm-brand))",
  teal: "rgb(var(--zm-positivo))",
  bg: "rgb(var(--zm-fundo))",
  card: "rgb(var(--zm-card))",
  linha: "rgb(var(--zm-linha))",
  cinza: "rgb(var(--zm-ink-muted))",
  ouro: "rgb(var(--zm-ouro))",
  aviso: "rgb(var(--zm-aviso))",
  perigo: "rgb(var(--zm-perigo))",
  sobre: "rgb(var(--zm-sobre))",
};

/**
 * O MENU DESTE ARQUIVO FOI APAGADO — ele estava MORTO e parecia vivo.
 *
 * `PainelNav` devolve `null` desde que o menu passou para a coluna do
 * `AppShell` (ver mais abaixo), mas a lista de itens continuou aqui, completa,
 * comentada e plausível. Ninguém a renderizava.
 *
 * O ESTRAGO NÃO É O BYTE PARADO, É A LEITURA. Ela tinha divergido do menu de
 * verdade (`Sidebar.tsx`): a lista daqui ainda trazia "WhatsApp" e "Liberação",
 * e não trazia Conversas, Jazigos, Conferência nem Memória. Quem viesse tirar
 * o WhatsApp do menu — e foi exatamente o que aconteceu — editaria esta lista,
 * daria o trabalho por feito e não mudaria nada na tela.
 *
 * O MENU DE VERDADE É `Sidebar.tsx`, e lá o WhatsApp já não estava.
 */


// Faixa de aviso que aparece em TODAS as telas do painel enquanto os disparos
// automáticos estiverem desligados — para não esquecer que a IA não responde
// sozinha durante a migração/captura das quadras.
function AvisoDisparos() {
  const [ligado, setLigado] = useState<boolean | null>(null);

  useEffect(() => {
    let vivo = true;
    fetch("/api/config/disparos")
      .then((r) => r.json())
      .then((j) => { if (vivo) setLigado(!!j?.ativo); })
      .catch(() => { if (vivo) setLigado(null); });
    return () => { vivo = false; };
  }, []);

  if (ligado !== false) return null; // só aparece quando está DESLIGADO

  return (
    <div style={{
      background: "rgb(var(--zm-perigo))", color: "#fff", padding: "10px 16px",
      display: "flex", alignItems: "center", justifyContent: "center",
      gap: 12, flexWrap: "wrap", fontSize: 14, textAlign: "center",
    }}>
      <span>⏸ <strong>Disparos automáticos desligados</strong> — a IA não responde sozinha e os avisos automáticos não saem.</span>
      <Link href="/painel/config" style={{
        color: "rgb(var(--zm-perigo))", background: "#fff", fontWeight: 700, textDecoration: "none",
        padding: "5px 12px", borderRadius: 8, fontSize: 13, whiteSpace: "nowrap",
      }}>Ligar na Config</Link>
    </div>
  );
}

/**
 * A NAVEGAÇÃO ANTIGA — agora vazia, de propósito.
 *
 * O menu passou para a coluna do `AppShell` (painel/layout.tsx), que envolve
 * todas as telas. As páginas continuam chamando `<PainelNav />` e isto não faz
 * nada: assim a troca aconteceu sem editar quinze arquivos de uma vez, e sem
 * risco de deixar uma tela sem menu no caminho.
 *
 * Conforme cada tela for reescrita no visual novo, a chamada sai junto.
 */
export function PainelNav(_: { atual?: string }) {
  return null;
}

const botaoBase: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 6,
  boxSizing: "border-box",
  lineHeight: 1.1,
  textDecoration: "none",
  borderRadius: 10,
  cursor: "pointer",
  fontWeight: 600,
};

export const painel: Record<string, React.CSSProperties> = {
  // O shell (painel/layout.tsx) já dá fundo, largura máxima e espaçamento.
  // Estes dois viraram neutros para as telas antigas não desenharem uma
  // segunda moldura por dentro da primeira.
  wrap: {},
  conteudo: {},
  h1: { fontSize: 22, fontWeight: 600, color: "rgb(var(--zm-ink))", margin: "0 0 16px" },
  card: { background: cor.card, border: `1px solid ${cor.linha}`, borderRadius: RAIO_CARTAO, padding: PAD_CARTAO, marginBottom: GAP_CARTAO, color: "rgb(var(--zm-ink))" },

  // ── Botões tamanho padrão ──
  // A altura vem de `medidas.ts`, e nao de um numero cravado aqui: `pecas.tsx`
  // usa a MESMA constante. Enquanto eram dois numeros, o sistema novo tinha 44
  // e o antigo 48, e ninguem notou — ver o comentario de `medidas.ts`.
  botao: { ...botaoBase, padding: "13px 20px", fontSize: 16, fontWeight: 700, border: "none", background: cor.navy, color: cor.sobre, minHeight: ALVO },
  botaoSec: { ...botaoBase, padding: "13px 18px", fontSize: TEXTO_CONTROLE, border: `1px solid ${cor.linha}`, background: cor.card, color: "rgb(var(--zm-ink))", minHeight: ALVO },
  botaoPerigo: { ...botaoBase, padding: "13px 18px", fontSize: TEXTO_CONTROLE, border: "none", background: "rgb(var(--zm-perigo))", color: "#fff", minHeight: ALVO },

  // ── Botões compactos (linhas densas de ação: uma medida única, sem improviso) ──
  // Antes cada tela inventava um padding ("4px 10px", "6px 12px", "8px 14px"…);
  // agora é um só tamanho para todos os botões pequenos.
  botaoMini: { ...botaoBase, padding: "8px 14px", fontSize: 14, fontWeight: 700, border: "none", background: cor.navy, color: cor.sobre, minHeight: ALVO_MINI },
  botaoMiniSec: { ...botaoBase, padding: "8px 14px", fontSize: 14, border: `1px solid ${cor.linha}`, background: cor.card, color: "rgb(var(--zm-ink))", minHeight: ALVO_MINI },
  botaoMiniPerigo: { ...botaoBase, padding: "8px 14px", fontSize: 14, border: "none", background: "rgb(var(--zm-perigo))", color: "#fff", minHeight: ALVO_MINI },

  // fontSize 16 evita o zoom automático do iOS ao focar o campo
  input: { width: "100%", padding: "10px 12px", fontSize: TEXTO_CONTROLE, minHeight: ALVO_CAMPO, borderRadius: RAIO_CONTROLE, border: `1px solid ${cor.linha}`, background: cor.card, color: "rgb(var(--zm-ink))", boxSizing: "border-box" },
  rotulo: { fontSize: 13, fontWeight: 500, color: cor.cinza, marginBottom: 4, display: "block" },
};

/**
 * DINHEIRO DIGITADO NO PADRAO BRASILEIRO.
 *
 * O <input type="number"> nao serve: no teclado do celular em pt-BR o usuario
 * digita "40,50" e o campo devolve string vazia — o valor sumia sem aviso e a
 * tela salvava 0. Os campos de dinheiro sao type="text" inputMode="decimal" e
 * passam por aqui.
 *
 * Devolve NaN (nunca 0) quando o texto e ambiguo ou invalido, para a tela
 * RECUSAR o salvamento em vez de gravar um numero inventado:
 *   "40,50" -> 40.5      "1.234,56" -> 1234.56     "40.5" -> 40.5
 *   "" -> NaN            "abc" -> NaN              "1,2,3" -> NaN
 *   "," -> NaN        (virgula solta nao e zero: era um campo apagado)
 *   "40.5,00" -> NaN  (nem 40,50 nem 405: "40.5" nao e milhar valido)
 *   "1.500" -> NaN    (1500 para quem escreve em pt-BR, 1,5 para quem escreve
 *                      em ingles — e o campo aceita os dois formatos. Um erro
 *                      de 1000x no honorario nao pode sair de um palpite:
 *                      devolve NaN e a tela pede "1500" ou "1.500,00".)
 */
export function numeroBR(v: any): number {
  const t = String(v ?? "").trim();
  if (!t || !/^[\d.,]+$/.test(t)) return NaN;
  if (!/\d/.test(t)) return NaN;
  if (/^\d{1,3}\.\d{3}$/.test(t)) return NaN;
  const virgulas = (t.match(/,/g) || []).length;
  const pontos = (t.match(/\./g) || []).length;
  if (virgulas > 1) return NaN;
  let limpo = t;
  if (virgulas === 1) {
    const i = t.indexOf(",");
    const inteiro = t.slice(0, i), dec = t.slice(i + 1);
    if (pontos && !/^\d{1,3}(\.\d{3})+$/.test(inteiro)) return NaN;
    limpo = inteiro.replace(/\./g, "") + (dec ? "." + dec : "");
  } else if (pontos > 1) {
    if (!/^\d{1,3}(\.\d{3})+$/.test(t)) return NaN;
    limpo = t.replace(/\./g, "");
  }
  const n = Number(limpo);
  return isFinite(n) ? n : NaN;
}

/**
 * Numero -> texto pt-BR com 2 casas ("40,50"), para preencher campo de dinheiro.
 * null/undefined/"" devolvem "" (campo vazio), nunca "0,00": preco inventado num
 * campo de dinheiro e pior que campo em branco.
 */
export function dinheiroBR(v: any): string {
  if (v === null || v === undefined || v === "") return "";
  const n = Number(v);
  if (!isFinite(n)) return "";
  return (Math.round(n * 100) / 100).toFixed(2).replace(".", ",");
}
