"use client";

import { useEffect, useState } from "react";
import { materialOuEnfileirar } from "@/lib/offline-fila";
import { useRecado } from "@/components/Dialogos";

interface Mat {
  id: string;
  nome: string;
  unidade: string;
  estoque: number;
  alerta_minimo: number;
}

/** Pedido de material pela ajudante: marca o que acabou e avisa o dono. */
export default function Materiais({ onFechar }: { onFechar: () => void }) {
  const recado = useRecado();
  const [itens, setItens] = useState<Mat[]>([]);
  const [marcados, setMarcados] = useState<Record<string, boolean>>({});
  const [outro, setOutro] = useState("");
  const [obs, setObs] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [pronto, setPronto] = useState(false);
  const [guardado, setGuardado] = useState(false);

  useEffect(() => {
    fetch("/api/config/materiais")
      .then((x) => x.json())
      .then((r) => r.ok && setItens(Array.isArray(r.materiais) ? r.materiais : []))
      .catch(() => {});
  }, []);

  async function enviar() {
    const lista = itens.filter((i) => marcados[i.id]).map((i) => ({ id: i.id, nome: i.nome, acabou: true }));
    if (outro.trim()) lista.push({ id: undefined as any, nome: outro.trim(), acabou: true });
    if (!lista.length && !obs.trim()) return;

    // PEDIR MATERIAL SEM SINAL (CP-04). Acabar a água no meio da quadra é o
    // caso comum, e é exatamente onde o sinal falta.
    setEnviando(true);
    const { desfecho, motivo } = await materialOuEnfileirar({ itens: lista, observacao: obs });
    setEnviando(false);

    if (desfecho === "perdido") {
      recado.erro("A memória do aparelho encheu e eu não consegui guardar o pedido.");
      return;
    }
    if (desfecho === "recusado") {
      recado.erro(`Não consegui enviar. ${motivo || "O sistema recusou."}`);
      return;
    }
    setGuardado(desfecho === "offline");
    setPronto(true);
  }

  if (pronto) {
    return (
      <div style={s.overlay}>
        <div style={s.caixa}>
          <div style={{ fontSize: 40, textAlign: "center" }}>✓</div>
          <p style={s.ok}>
            {guardado
              ? "Pedido guardado! Assim que o sinal voltar ele sobe sozinho e a Sureya é avisada."
              : "Pedido enviado! A Sureya já foi avisada do que está faltando."}
          </p>
          <button style={s.botao} onClick={onFechar}>Fechar</button>
        </div>
      </div>
    );
  }

  return (
    <div style={s.overlay}>
      <div style={s.caixa}>
        <div style={s.topo}>
          <strong style={{ fontSize: 18 }}>O que está faltando?</strong>
          <button style={s.fechar} onClick={onFechar}>✕</button>
        </div>
        <p style={s.dica}>Marque o que acabou ou está no fim. A Sureya recebe o aviso na hora.</p>

        <div style={s.lista}>
          {itens.length === 0 && <p style={s.dica}>Nenhum material cadastrado ainda — use o campo abaixo.</p>}
          {(itens || []).map((i) => {
            const baixo = Number(i.estoque) <= Number(i.alerta_minimo);
            return (
              <label key={i.id} style={{ ...s.item, ...(marcados[i.id] ? s.itemMarcado : {}) }}>
                <input
                  type="checkbox"
                  checked={!!marcados[i.id]}
                  onChange={(e) => setMarcados({ ...marcados, [i.id]: e.target.checked })}
                  style={{ width: 22, height: 22 }}
                />
                <span style={{ flex: 1, textTransform: "capitalize" }}>{i.nome}</span>
                <span style={{ fontSize: 17, color: baixo ? "#dc2626" : "#475569" }}>
                  {baixo ? "já está baixo" : `${i.estoque} ${i.unidade}`}
                </span>
              </label>
            );
          })}
        </div>

        <input
          style={s.input}
          value={outro}
          onChange={(e) => setOutro(e.target.value)}
          placeholder="Outro item que não está na lista"
        />
        <textarea
          style={{ ...s.input, minHeight: 60, resize: "vertical" }}
          value={obs}
          onChange={(e) => setObs(e.target.value)}
          placeholder="Quer dizer mais alguma coisa? (opcional)"
        />

        <button style={s.botao} onClick={enviar} disabled={enviando}>
          {enviando ? "Enviando…" : "Enviar pedido"}
        </button>
      </div>
    </div>
  );
}

const TEAL = "#0f766e";
const s: Record<string, React.CSSProperties> = {
  overlay: { position: "fixed", inset: 0, background: "rgba(15,23,42,.6)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 60 },
  caixa: { background: "#fff", width: "100%", maxWidth: 520, borderRadius: "16px 16px 0 0", padding: 18, maxHeight: "92vh", overflowY: "auto" },
  topo: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 },
  fechar: { background: "none", border: "none", fontSize: 22, cursor: "pointer", color: "#475569" },
  dica: { color: "#475569", fontSize: 18, margin: "4px 0 12px" },
  lista: { marginBottom: 12 },
  item: { display: "flex", alignItems: "center", gap: 12, minHeight: 56, padding: "16px 14px", border: "1px solid #e2e8f0", borderRadius: 12, marginBottom: 8, fontSize: 18, cursor: "pointer" },
  itemMarcado: { background: "#fef3c7", borderColor: "#fde68a" },
  input: { width: "100%", padding: 12, fontSize: 18, borderRadius: 10, border: "1px solid #e2e8f0", boxSizing: "border-box", marginBottom: 10, fontFamily: "inherit" },
  botao: { width: "100%", minHeight: 60, padding: 17, background: TEAL, color: "#fff", border: "none", borderRadius: 14, fontSize: 18, fontWeight: 700, cursor: "pointer" },
  ok: { textAlign: "center", fontSize: 18, color: "#0f172a", margin: "10px 0 18px" },
};
