import { NextRequest, NextResponse } from "next/server";
import { exigirAdmin } from "@/lib/roles";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await exigirAdmin();
  if (auth.erro) return auth.erro;
  const db = auth.db;

  const id = params.id;

  const { data: cliente } = await db
    .from("clientes")
    .select("id,nome,apelido,foto_url,telefone,modo,score,ativo_ia,instrucoes_ia,perfil_ia,observacoes,consentimento_em,codigo_indicacao,tratamento,regua_cobranca,dias_entre_cobrancas,max_lembretes,orientacao_cobranca,cobranca_nivel,ativacao_ativa,ativacao_meses,ultima_ativacao_em,cobranca_antecipada")
    .eq("id", id)
    .maybeSingle();
  if (!cliente) return NextResponse.json({ ok: false, erro: "nao_encontrado" }, { status: 404 });

  const [{ data: tumulos }, { data: planos }, { data: mov }, { data: msgs }] = await Promise.all([
    db.from("tumulos").select("id,identificacao,numero,falecido_nome,datas_gatilho,qr_token,rua,quadra_id,lat,lng,gps_precisao,gps_amostras,foto_referencia_url,foto_enquadramento_url,quadras(codigo)").eq("cliente_id", id),
    db.from("planos").select("id,tumulo_id,cadencia,qtd_por_passagem,lavagens_por_ciclo,valor_vigente,valor_mensal,data_valor_vigente,ativo,pago_ate,proxima_cobranca,proximo_servico,migrado_em,momento_cobranca").eq("cliente_id", id),
    db.from("movimentos").select("id,tipo,valor,status_conc,data,descricao").eq("cliente_id", id).order("data", { ascending: false }),
    db.from("mensagens").select("autor,texto,created_at").eq("cliente_id", id).order("created_at", { ascending: false }).limit(15),
  ]);

  let saldo = 0;
  let aConferir = 0;
  const pagamentos: any[] = [];
  for (const m of mov || []) {
    const st = (m as any).status_conc;
    const v = Number((m as any).valor) || 0;
    if (st === "rejeitado") continue;
    if (st === "a_conferir") { if ((m as any).tipo === "credito") aConferir += v; continue; }
    saldo += (m as any).tipo === "credito" ? v : -v;
    if ((m as any).tipo === "credito") pagamentos.push({ id: (m as any).id, valor: v, data: (m as any).data });
  }

  return NextResponse.json({
    ok: true,
    cliente,
    tumulos: tumulos || [],
    planos: planos || [],
    saldo,
    aConferir,
    pagamentos,
    mensagens: (msgs || []).reverse(),
  });
}

// PATCH { nome?, telefone?, modo?, ativo_ia?, instrucoes_ia?, observacoes? }
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await exigirAdmin();
  if (auth.erro) return auth.erro;
  const db = auth.db;

  const body = await req.json().catch(() => ({}));
  const camposRegua = [
    "tratamento", "regua_cobranca", "dias_entre_cobrancas", "max_lembretes",
    "orientacao_cobranca", "ativacao_ativa", "ativacao_meses", "cobranca_antecipada",
    "apelido",
  ] as const;
  const patch: Record<string, any> = {};
  for (const campo of ["nome", "telefone", "modo", "ativo_ia", "instrucoes_ia", "observacoes", ...camposRegua]) {
    if (body[campo] !== undefined) patch[campo] = body[campo];
  }
  if (!Object.keys(patch).length) {
    return NextResponse.json({ ok: false, erro: "nada_para_atualizar" }, { status: 400 });
  }

  // guarda o que mudou em nome e telefone — são os campos que se perdem de vista
  if (patch.nome !== undefined || patch.telefone !== undefined) {
    const { data: antes } = await db
      .from("clientes").select("org_id,nome,telefone").eq("id", params.id).maybeSingle();
    if (antes) {
      const mudancas: any[] = [];
      for (const campo of ["nome", "telefone"] as const) {
        if (patch[campo] !== undefined && patch[campo] !== (antes as any)[campo]) {
          mudancas.push({
            org_id: (antes as any).org_id, cliente_id: params.id, campo,
            de: (antes as any)[campo], para: patch[campo], user_id: auth.userId,
          });
        }
      }
      if (mudancas.length) await db.from("historico_cliente").insert(mudancas);
    }
  }

  const { error } = await db.from("clientes").update(patch).eq("id", params.id);
  if (error) return NextResponse.json({ ok: false, erro: error.message }, { status: 500 });

  return NextResponse.json({ ok: true });
}


// DELETE — remove o cliente e tudo que depende dele.
// Só permite se NÃO houver movimento financeiro; nesse caso, oriente a anonimizar
// (LGPD), que preserva o histórico contábil.
export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const auth = await exigirAdmin();
  if (auth.erro) return auth.erro;
  const db = auth.db;

  const { count } = await db
    .from("movimentos").select("id", { count: "exact", head: true }).eq("cliente_id", params.id);
  if ((count || 0) > 0) {
    return NextResponse.json(
      { ok: false, erro: "tem_movimento_financeiro",
        mensagem: "Esta família já tem lançamentos no financeiro. Excluir apagaria o histórico. Use 'Remover dados' (LGPD), que preserva a contabilidade." },
      { status: 400 }
    );
  }

  await db.from("mensagens").delete().eq("cliente_id", params.id);
  await db.from("interacoes_ia").delete().eq("cliente_id", params.id);
  await db.from("conversas").delete().eq("cliente_id", params.id);
  await db.from("servicos").delete().eq("cliente_id", params.id);
  await db.from("planos").delete().eq("cliente_id", params.id);
  await db.from("tumulos").delete().eq("cliente_id", params.id);
  const { error } = await db.from("clientes").delete().eq("id", params.id);
  if (error) return NextResponse.json({ ok: false, erro: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
