"use client";

import { useEffect, useRef, useState } from "react";
import { useParams } from "next/navigation";
import { PainelNav, painel, cor } from "../../ui";
import { PedidosAdicionais, AnotarPedido } from "../../PedidosAdicionais";
import Compromissos from "../Compromissos";
import { useConfirmar, useRecado } from "@/components/Dialogos";
import ContaDaFamilia from "./ContaDaFamilia";
import Modelos from "./Modelos";

export default function Thread() {
  const recado = useRecado();
  const perguntar = useConfirmar();
  const params = useParams();
  const id = params?.id as string;
  const [d, setD] = useState<any>(null);
  const [texto, setTexto] = useState("");
  const [ocupado, setOcupado] = useState(false);
  const fim = useRef<HTMLDivElement>(null);
  const [versaoPedidos, setVersaoPedidos] = useState(0);
  /** A sugestão da IA, e o que ela leu para escrever. */
  const [sugerindo, setSugerindo] = useState(false);
  const [leu, setLeu] = useState<number | null>(null);
  /** Quantas promessas desta conversa ainda estão em aberto (0142). */
  const [promessas, setPromessas] = useState(0);
  // A PRÓXIMA DA FILA. Vem da MESMA rota que desenha a lista — a ordem da fila
  // é feita de quatro regras e repeti-las aqui daria uma quinta.
  const [fila, setFila] = useState<{ proxima: { id: string; cliente: string } | null; naFila: number } | null>(null);
  // O recado do envio. Fica FORA do try/finally do `enviar` porque ele
  // precisa sobreviver ao fim da chamada — e some so quando ela tenta de novo.
  const [avisoEnvio, setAvisoEnvio] = useState<{ tom: "erro" | "aviso"; texto: string } | null>(null);

  /**
   * SUGERIR RESPOSTA — a IA lê tudo e escreve uma proposta no campo.
   *
   * Não é o robô de volta. O robô respondia sozinho e foi desligado por um bom
   * motivo (D-12). Aqui a IA escreve NO CAMPO DE TEXTO e para por aí: quem lê,
   * corrige, apaga e envia é a pessoa.
   *
   * O que ela ganha com isso não é digitação, é MEMÓRIA: para responder bem é
   * preciso saber que esta família tem dois jazigos, que a última limpeza foi
   * há seis dias, que está R$ 80 adiantada e que a régua dela é "suave" — cinco
   * telas. A proposta chega com isso considerado.
   *
   * Substituir o que já está escrito exige confirmação: a frase que ela digitou
   * é dela, e uma sugestão que apaga o trabalho de alguém não é ajuda.
   */
  async function sugerir() {
    if (texto.trim() && !await perguntar({
      oQue: "Substituir o que você já escreveu pela sugestão da IA?",
      efeito: "O seu texto se perde. Se quiser guardar, copie antes.",
      confirmar: "Substituir", tom: "perigo",
    })) return;
    setSugerindo(true);
    setLeu(null);
    try {
      const r = await fetch(`/api/conversas/${id}/sugerir`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      }).then((x) => x.json()).catch(() => null);
      if (!r?.ok) { recado.erro(r?.mensagem || "Não consegui sugerir agora. Escreva à mão."); return; }
      setTexto(r.texto);
      setLeu(Number(r.mensagensLidas) || 0);
    } finally { setSugerindo(false); }
  }

  async function carregar() {
    const r = await fetch(`/api/conversas/${id}`).then((x) => x.json());
    if (r.ok) {
      setD(r);
    }
    // As promessas em aberto vêm da MESMA rota que a caixa acima usa — uma
    // definição só de "em aberto", senão o aviso de finalizar discordaria da
    // caixa que está na tela dois centímetros acima.
    fetch(`/api/conversas?situacao=pendentes&proximaDe=${encodeURIComponent(id)}`)
      .then((x) => x.json())
      .then((j) => setFila(j?.ok ? { proxima: j.proxima || null, naFila: Number(j.naFila) || 0 } : null))
      // A fila é conforto, não o trabalho: se ela não carregar, o botão some e
      // a conversa continua inteira. Derrubar a tela por causa dele seria pior.
      .catch(() => setFila(null));

    const p = await fetch(`/api/compromissos?conversa=${encodeURIComponent(id)}`)
      .then((x) => x.json()).catch(() => null);
    setPromessas(p?.ok ? (p.compromissos || []).length : 0);
  }
  useEffect(() => {
    if (id) carregar();
  }, [id]);
  useEffect(() => {
    fim.current?.scrollIntoView();
  }, [d]);

  /**
   * UMA CAIXA SÓ, E O QUE VAI É O QUE ESTÁ NELA.
   *
   * -------------------------------------------------------------------------
   * O QUE ACONTECEU COM A JOSEFINA, EM 29/08
   * -------------------------------------------------------------------------
   *   09:10  a IA rascunha uma resposta sobre luto ("Sinto muito pela sua mãe")
   *   12:35  a família volta e pergunta OUTRA coisa: "Qual valor", "quando vc
   *          poderia vir"
   *   16:59  o rascunho das 9h sai, palavra por palavra
   *
   * Havia DUAS caixas de texto na tela e TRÊS botões de enviar. Ele reescreveu
   * o texto na caixa do rascunho e clicou em "Aprovar e enviar" — o único dos
   * botões que NÃO olhava para a caixa. Foi o rascunho de oito horas antes,
   * respondendo um assunto que já tinha passado.
   *
   * Dois campos editáveis para a mesma resposta, com botões que dizem a mesma
   * coisa e fazem coisas diferentes: o erro não foi dele.
   *
   * Agora há UMA caixa. A sugestão da IA entra NELA — que é o que "Sugerir
   * resposta" já fazia — e o envio é um só. Não existe mais um caminho que
   * mande outra coisa que não o que está escrito na tela.
   */
  /**
   * O QUE ACONTECEU EM 02/09, COM A ELIETE
   *
   * Ele escreveu a resposta, clicou em Enviar, a caixa esvaziou e a tela
   * recarregou. A mensagem nao chegou na familia. Nao houve erro na tela.
   *
   * Este `enviar` mandava o `fetch` e NUNCA OLHAVA A RESPOSTA: limpava a caixa
   * e recarregava tivesse a rota respondido 200, 400 ou 500. Do outro lado, a
   * rota chamava um envio que LANCA quando o WhatsApp recusa — e a mensagem
   * nao saia, nao ficava em fila e nao era gravada em lugar nenhum.
   *
   * Medido: 161 interacoes com acao humana, 58 saidas no total, ultima saida do
   * dia anterior. Nao da para saber quantas se perderam antes desta, porque
   * perder em silencio nao deixa marca — e essa e exatamente a razao de o
   * conserto precisar existir.
   *
   * Agora: se falhou, O TEXTO FICA NA CAIXA e a tela diz o que houve. Se saiu
   * mas ficou na fila de reenvio, tambem diz — nao e a mesma coisa que chegar.
   */
  async function enviar() {
    const t = texto.trim();
    if (!t) return;
    setOcupado(true);
    setAvisoEnvio(null);
    try {
      // COM RASCUNHO PENDENTE, O ENVIO PASSA POR ELE — senão a interação ficaria
      // aberta para sempre e a IA continuaria "esperando decisão" sobre uma
      // resposta que já foi. A rota deduz sozinha se foi aprovada ou editada,
      // comparando com o rascunho original.
      const r = d?.rascunho?.id
        ? await fetch("/api/atendimento/aprovar", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ interacaoId: d.rascunho.id, acao: "editou", textoFinal: t }),
          })
        : await fetch(`/api/conversas/${id}/enviar`, {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ texto: t }),
          });

      const j = await r.json().catch(() => ({}));
      if (!r.ok || !(j as any).ok) {
        // O TEXTO NAO SE PERDE. Quem escreveu tres paragrafos para uma familia
        // enlutada nao pode ter que reescrever porque o WhatsApp recusou.
        setAvisoEnvio({
          tom: "erro",
          texto: "A mensagem NÃO foi enviada. O seu texto continua aqui na caixa. "
               + ((j as any)?.erro ? `O WhatsApp respondeu: ${(j as any).erro}` : "Tente de novo em instantes."),
        });
        return;
      }

      if ((j as any).entregue === false) {
        setAvisoEnvio({
          tom: "aviso",
          texto: "Não saiu agora — ficou na fila e o sistema vai tentar de novo sozinho. "
               + "Confira em Configurações se o WhatsApp está conectado.",
        });
      }
      setTexto("");
      carregar();
    } catch (e: any) {
      setAvisoEnvio({
        tom: "erro",
        texto: "Não consegui falar com o servidor. A mensagem NÃO foi enviada e o seu texto continua aqui.",
      });
    } finally { setOcupado(false); }
  }

  /** Joga a sugestão da IA na caixa. Daí em diante ela é texto seu. */
  async function usarSugestao() {
    if (texto.trim() && !await perguntar({
      oQue: "Substituir o que você já escreveu pela sugestão da IA?",
      efeito: "O seu texto se perde. Se quiser guardar, copie antes.",
      confirmar: "Substituir", tom: "perigo",
    })) return;
    setTexto(d?.rascunho?.rascunho || "");
  }

  async function descartarRascunho() {
    setOcupado(true);
    try {
      await fetch("/api/atendimento/aprovar", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ interacaoId: d.rascunho.id, acao: "descartou" }),
      });
      carregar();
    } finally { setOcupado(false); }
  }

  /**
   * FINALIZAR O ATENDIMENTO — de dentro da conversa.
   *
   * "Resolver" e "Arquivar" existiam só na LISTA. Mas o momento em que se sabe
   * que o assunto acabou é o momento em que se acabou de responder — e esse
   * momento acontece AQUI. Ter de voltar para a lista, achar a linha e agir de
   * fora é fricção no lugar exato onde ela custa mais: o que dá trabalho fica
   * para depois, e "depois" é como a fila de 164 mensagens nasceu.
   *
   * A CONVERSA VOLTA PARA A IA JUNTO. `resolver` já apaga `escalada_humano` no
   * banco; deixar a conversa resolvida E assumida seria dizer duas coisas
   * contrárias sobre a mesma linha.
   */
  async function finalizar() {
    // PROMESSA EM ABERTO É MOTIVO PARA PARAR E OLHAR.
    //
    // Fechar o atendimento com uma promessa pendente é exatamente o defeito que
    // a 0142 mediu: a família esperando um retorno que ninguém sabia que devia.
    // Não proíbe — às vezes a resposta acabou de sair pela fila —, mas não
    // deixa acontecer sem ver.
    const aviso = promessas > 0
      ? `Ainda há ${promessas === 1 ? "uma promessa em aberto" : `${promessas} promessas em aberto`} `
        + "nesta conversa. Se já respondeu, feche a promessa também — senão ela "
        + "continua cobrando você no “Precisa de você”."
      : "A conversa sai da fila de pendentes e volta para a IA. "
        + "Ela reabre sozinha se a família escrever de novo.";

    if (!await perguntar({
      oQue: "Finalizar o atendimento desta conversa?",
      efeito: aviso,
      confirmar: "Finalizar", tom: promessas > 0 ? "perigo" : "normal",
    })) return;

    setOcupado(true);
    try {
      const r = await fetch(`/api/conversas/${id}/acao`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ acao: "resolver" }),
      }).then((x) => x.json()).catch(() => null);
      if (!r?.ok) { recado.erro(r?.erro || "Não consegui finalizar agora."); return; }
      // FINALIZOU: A PRÓXIMA JÁ. Voltar para a lista, achar onde parou e abrir
      // a linha seguinte é a fricção que faz o que dá trabalho ficar para
      // depois — e "depois" é como a fila de 164 mensagens nasceu. O rótulo do
      // botão diz que isso vai acontecer, então não é surpresa.
      if (fila?.proxima) { irParaProxima(); return; }
      recado.ok("Atendimento finalizado. Não há mais ninguém esperando resposta.");
      carregar();
    } finally { setOcupado(false); }
  }

  /**
   * IR PARA A PRÓXIMA — sem passar pela lista.
   *
   * MEDIDO EM 02/09: 197 conversas "não resolvidas", e apenas 31 esperando
   * resposta de alguém. Por isso a próxima sai da FILA (o que precisa de você),
   * e não de "tudo que não foi resolvido": andar pelas 197 seria passear por
   * 166 conversas sem nada a fazer.
   */
  function irParaProxima() {
    const alvo = fila?.proxima;
    if (!alvo) return;
    // `location.href` e não router.push: a página inteira recarrega, e com ela
    // todo o estado — caixa de texto, sugestão da IA, compromissos. Levar o
    // rascunho de uma família para a conversa de outra é o erro que a caixa
    // única acabou de consertar; não vou reabri-lo por outra porta.
    window.location.href = `/painel/conversas/${alvo.id}`;
  }

  async function reabrir() {
    setOcupado(true);
    try {
      await fetch(`/api/conversas/${id}/acao`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ acao: "reabrir" }),
      });
      carregar();
    } finally { setOcupado(false); }
  }

  async function alternarIa() {
    setOcupado(true);
    await fetch(`/api/conversas/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ escalada_humano: !d.conversa.escalada }),
    });
    setOcupado(false);
    carregar();
  }

  /**
   * QUANTO TEMPO O RASCUNHO TEM, e quantas mensagens chegaram depois dele.
   *
   * O da Josefina tinha OITO HORAS e respondia luto; entre ele e o envio a
   * família perguntou preço e data. Um rascunho velho não é só desatualizado —
   * ele responde outra conversa.
   */
  const nascidoEm = d?.rascunho?.created_at ? new Date(d.rascunho.created_at).getTime() : 0;
  const horas = nascidoEm ? Math.floor((Date.now() - nascidoEm) / 3600000) : 0;
  const msgsDepois = nascidoEm
    ? (d?.mensagens || []).filter((m: any) =>
        m.autor === "cliente" && new Date(m.created_at || 0).getTime() > nascidoEm).length
    : 0;
  // Velho é ter mais de duas horas OU ter chegado mensagem depois — o segundo
  // caso importa mais: dez minutos bastam se a família mudou de assunto.
  const rascunhoVelho = !!nascidoEm && (horas >= 2 || msgsDepois > 0);
  const idadeRascunho = horas >= 24
    ? `há ${Math.floor(horas / 24)} dia${horas >= 48 ? "s" : ""}`
    : horas >= 1 ? `há ${horas}h` : "agora há pouco";

  if (!d) {
    return (
      <div style={painel.wrap}>
        <PainelNav atual="/painel/conversas" />
        <div style={painel.conteudo}><p style={{ color: cor.cinza }}>Carregando…</p></div>
      </div>
    );
  }

  return (
    <div style={painel.wrap}>
      <PainelNav atual="/painel/conversas" />
      <div style={painel.conteudo}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center",
                      gap: 10, flexWrap: "wrap" }}>
          <h1 style={{ ...painel.h1, marginRight: "auto" }}>{d.conversa.cliente}</h1>
          <button style={d.conversa.escalada ? painel.botao : painel.botaoSec} onClick={alternarIa} disabled={ocupado}>
            {d.conversa.escalada ? "Devolver para a IA" : "Assumir conversa"}
          </button>
          {/* FINALIZAR MORA AQUI, e não só na lista.
              O momento em que se sabe que o assunto acabou é o momento em que
              se acabou de responder — e esse momento acontece nesta tela. */}
          {d.conversa.resolvida
            ? <button style={painel.botaoSec} onClick={reabrir} disabled={ocupado}>
                Reabrir atendimento
              </button>
            : <button style={painel.botaoSec} onClick={finalizar} disabled={ocupado}>
                {/* O RÓTULO DIZ O QUE VAI ACONTECER. Finalizar e ser levado
                    para outra conversa sem aviso seria um susto; escrito no
                    botão, é o fluxo de quem está limpando a fila. */}
                {fila?.proxima ? "Finalizar e ir para a próxima" : "Finalizar atendimento"}
              </button>}

          {/* IR PARA A PRÓXIMA SEM FINALIZAR — para quem só quer passar
              adiante o que ainda não dá para fechar. */}
          {fila?.proxima && (
            <button style={painel.botaoSec} onClick={irParaProxima} disabled={ocupado}
                    title={`Próxima: ${fila.proxima.cliente}`}>
              Próxima →
            </button>
          )}
        </div>
        <p style={{ color: cor.cinza, marginTop: -10, fontSize: 14 }}>
          {d.conversa.resolvida
            ? "Atendimento finalizado — ela reabre sozinha se a família escrever de novo."
            : d.conversa.escalada ? "Você está atendendo — a IA não responde."
            : "A IA está atendendo (rascunhos aparecem aqui)."}
          {/* QUANTAS AINDA PRECISAM DE VOCÊ, contando esta. É o número da fila
              filtrada (31 em 02/09), e não o de conversas não resolvidas (197):
              dizer 197 aqui faria a fila parecer intransponível quando ela cabe
              numa manhã. `fila` nulo é "não consegui ler", e nesse caso não se
              diz número nenhum — vazio não é zero. */}
          {fila && fila.naFila > 0 && (
            <span> · {fila.naFila === 1
              ? "é a última que precisa de você"
              : `${fila.naFila} precisam de você`}</span>
          )}
        </p>

        {/* A CONTA DA FAMÍLIA — antes das mensagens, pelo mesmo motivo dos
            compromissos: para responder um comprovante é preciso saber de qual
            mês ele é, e essa resposta estava a três telas daqui. */}
        <ContaDaFamilia familiaId={d.conversa.familiaId} />

        {/* O QUE VOCÊ PROMETEU E AINDA NÃO RESPONDEU (0142).
            Antes das mensagens, porque quem abre a conversa para responder
            precisa saber disso ANTES de escrever. */}
        <Compromissos key={`k${versaoPedidos}`} conversaId={id} />

        {/* pedido de servico adicional feito nesta conversa */}
        <PedidosAdicionais key={versaoPedidos} conversaId={id} />

        <div style={{ ...painel.card, maxHeight: 420, overflowY: "auto" }}>
          {d.mensagens.length === 0 && <p style={{ color: cor.cinza }}>Sem mensagens ainda.</p>}
          {(d.mensagens || []).map((m: any, i: number) => (
            <div key={i} style={{ margin: "8px 0", textAlign: m.autor === "cliente" ? "left" : "right" }}>
              <span style={{ display: "inline-block", maxWidth: "80%", padding: "8px 12px", borderRadius: 12, background: m.autor === "cliente" ? "#e2e8f0" : m.autor === "ia" ? "#0f766e" : "#1e293b", color: m.autor === "cliente" ? cor.navy : "#fff", fontSize: 14 }}>
                {m.transcrita && (
                <span style={{ display: "block", fontSize: 15, color: cor.cinza,
                               marginBottom: 4, fontStyle: "italic" }}>
                  🎤 áudio transcrito
                </span>
              )}
              {/* A IMAGEM QUE A FAMÍLIA MANDOU.
                  Ela era baixada, lida pelo leitor de comprovante e descartada
                  quando ele não a reconhecia — justamente quando alguém precisa
                  olhar. A Sureya lia "não parece um comprovante" e não tinha
                  como saber se era a foto do túmulo, um print de outro banco ou
                  uma dúvida escrita à mão. Tocar abre em tamanho cheio. */}
              {m.midia_url && (
                <a href={m.midia_url} target="_blank" rel="noreferrer"
                   style={{ display: "block", marginBottom: 6 }}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={m.midia_url} alt="imagem enviada pela família"
                       style={{ maxWidth: "100%", maxHeight: 320, borderRadius: 10, display: "block" }} />
                </a>
              )}
              {/* NÃO CONSEGUI ABRIR ≠ NÃO TEM IMAGEM (0139).
                  O balde das conversas fechou, e a imagem passa a ser lida por
                  link que expira. Se ele não sair, calar faria a mensagem
                  parecer que a família nunca mandou foto — que é exatamente o
                  defeito que a 0134 consertou pela outra ponta. */}
              {m.midia_falhou && (
                <div style={{
                  marginBottom: 6, padding: "8px 10px", borderRadius: 10,
                  border: "1px solid rgb(var(--zm-aviso) / 0.4)",
                  background: "rgb(var(--zm-aviso) / 0.1)",
                  color: "rgb(var(--zm-aviso))", fontSize: 12.5, lineHeight: 1.45,
                }}>
                  A família mandou uma imagem aqui e eu não consegui abri-la agora.
                  Recarregue a conversa; se continuar, o arquivo pode ter sido removido.
                </div>
              )}
              {m.texto}
                <div style={{ fontSize: 10, opacity: 0.7, marginTop: 2 }}>
                  {m.pelo_celular ? "você · pelo celular" : m.autor}
                </div>
              </span>
            </div>
          ))}
          <div ref={fim} />
        </div>

        {/* A SUGESTÃO DA IA NÃO É MAIS UMA SEGUNDA CAIXA — é um cartão de
            leitura, com um botão que joga o texto na caixa de baixo.

            Ela era editável, e tinha três botões de envio ao lado. Um deles,
            "Aprovar e enviar", era o único que NÃO olhava para o que estava
            escrito ali: mandava o rascunho do banco. Foi assim que a resposta
            de 09:10 saiu às 16:59 para a Josefina, falando de luto quando ela
            já tinha perguntado preço e data. */}
        {d.rascunho && (
          <div style={{ ...painel.card, borderColor: "#fbbf24", background: "#fffbeb" }}>
            <div style={painel.rotulo}>
              A IA sugeriu uma resposta
              {rascunhoVelho && (
                <b style={{ color: "rgb(var(--zm-perigo))" }}> · escrita {idadeRascunho}</b>
              )}
            </div>
            {d.rascunho.motivo_retencao && (
              <p style={{ fontSize: 15, color: "#92400e", margin: "0 0 8px" }}>
                Não foi automático porque: {d.rascunho.motivo_retencao}
              </p>
            )}

            {/* O RASCUNHO VELHO É O PERIGO DE VERDADE. O da Josefina tinha oito
                horas e respondia um assunto que já tinha passado — e nada na
                tela dizia isso. */}
            {rascunhoVelho && (
              <p style={{ fontSize: 14, color: "rgb(var(--zm-perigo))", margin: "0 0 8px",
                          lineHeight: 1.5 }}>
                <b>Cuidado:</b> esta sugestão foi escrita {idadeRascunho}
                {msgsDepois > 0
                  ? `, e a família mandou ${msgsDepois === 1 ? "mais uma mensagem" : `mais ${msgsDepois} mensagens`} depois disso.`
                  : "."}{" "}
                Leia a conversa antes de usar — ela pode estar respondendo outra coisa.
              </p>
            )}

            <p style={{ whiteSpace: "pre-wrap", fontSize: 15, lineHeight: 1.5,
                        margin: "0 0 10px", color: "rgb(var(--zm-ink))" }}>
              {d.rascunho.rascunho}
            </p>

            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button style={painel.botao} disabled={ocupado} onClick={usarSugestao}>
                Usar esta resposta
              </button>
              <button style={painel.botaoPerigo} disabled={ocupado} onClick={descartarRascunho}>
                Descartar
              </button>
            </div>
            <p style={{ fontSize: 13, color: cor.cinza, margin: "8px 0 0", lineHeight: 1.45 }}>
              “Usar esta resposta” copia o texto para a caixa abaixo. Você corrige lá, e
              o que for enviado é <b>exatamente o que estiver escrito nela</b>.
            </p>
          </div>
        )}

        <div>
          {/* AS MENSAGENS PRONTAS VÊM ANTES DA CAIXA e antes do botão da IA:
              o caminho barato precisa estar no caminho, não escondido atrás
              dele. Ver Modelos.tsx para os números que justificam isso. */}
          <Modelos conversaId={id} temTexto={!!texto.trim()} aoEscolher={setTexto} />

          {/* O RECADO DO ENVIO FICA COLADO NA CAIXA, e nao no topo da tela: e
              aqui que a pessoa esta olhando quando clica em Enviar. */}
          {avisoEnvio && (
            <div style={{ marginBottom: 8, padding: "10px 12px", borderRadius: 10,
                          fontSize: 15, lineHeight: 1.5,
                          background: avisoEnvio.tom === "erro"
                            ? "rgb(var(--zm-perigo) / 0.10)" : "rgb(var(--zm-aviso) / 0.12)",
                          border: `1px solid ${avisoEnvio.tom === "erro"
                            ? "rgb(var(--zm-perigo))" : "rgb(var(--zm-aviso))"}`,
                          color: "rgb(var(--zm-ink))" }}>
              {avisoEnvio.texto}
            </div>
          )}
          <textarea
            rows={5}
            style={{ ...painel.input, width: "100%", minHeight: 130, resize: "vertical",
                     fontFamily: "inherit", lineHeight: 1.5 }}
            placeholder="Escreva uma mensagem…"
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
            onKeyDown={(e) => {
              // Enter quebra linha (mensagem longa é normal aqui).
              // Ctrl+Enter ou Cmd+Enter envia.
              if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) enviar();
            }}
          />
          <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 8, flexWrap: "wrap" }}>
            <button style={painel.botao} onClick={enviar} disabled={ocupado || !texto.trim()}>
              Enviar
            </button>
            {/* A IA ESCREVE, VOCÊ MANDA.
                Fica ao lado de Enviar e não dentro de um painel que precisa ser
                aberto: é para o caso comum — responder o que a família acabou
                de perguntar —, e um caso comum atrás de dois cliques não é
                usado. O "Me ajuda a escrever", logo abaixo, é para quando ela
                já sabe o que quer dizer e quer três jeitos de dizer. */}
            <button style={painel.botaoSec} onClick={sugerir} disabled={sugerindo || ocupado}>
              {sugerindo ? "A IA está lendo a conversa…" : "🤖 Sugerir resposta"}
            </button>
            <span style={{ fontSize: 14, color: cor.cinza }}>
              Enter quebra linha · Ctrl+Enter envia
            </span>
          </div>
          {/* Dizer QUANTO ela leu, em vez de pedir fé. Uma sugestão que ignorou
              o combinado de três semanas atrás é pior que sugestão nenhuma, e
              quem revisa precisa saber com o que está lidando. */}
          {leu !== null && (
            <p style={{ fontSize: 13, color: cor.cinza, margin: "6px 0 0" }}>
              A IA leu {leu === 0 ? "o cadastro da família (a conversa ainda não tem mensagens)"
                                  : `as ${leu} últimas mensagens desta conversa`}, os jazigos, o
              saldo e a régua de cobrança. <b>Revise antes de enviar</b> — o que estiver entre
              colchetes é coisa que ela não sabia.
            </p>
          )}
        </div>
        <div style={{ marginTop: 12 }}>
          <AnotarPedido
            conversaId={id}
            clienteId={d.conversa.clienteId || null}
            aoPronto={() => setVersaoPedidos((v) => v + 1)}
          />
        </div>

        <MeAjuda conversaId={id} onEscolher={(t) => setTexto(t)} />
      </div>
    </div>
  );
}


/**
 * "Me ajuda a escrever" — você dá o contexto e o tom; a IA devolve três
 * caminhos diferentes. Escolhe um, ajusta e manda. Nada sai sozinho.
 */
function MeAjuda({ conversaId, onEscolher }: { conversaId: string; onEscolher: (t: string) => void }) {
  const recado = useRecado();
  const [aberto, setAberto] = useState(false);
  const [contexto, setContexto] = useState("");
  const [tom, setTom] = useState("acolhedor");
  const [opcoes, setOpcoes] = useState<any[]>([]);
  const [pensando, setPensando] = useState(false);
  const [copiado, setCopiado] = useState<number | null>(null);

  /** Edita uma sugestão no lugar, guardando o texto original para poder desfazer. */
  function trocarTexto(i: number, texto: string) {
    setOpcoes((atual) =>
      atual.map((o, idx) => (idx === i ? { ...o, texto } : o))
    );
  }

  async function pedir() {
    setPensando(true);
    setOpcoes([]);
    const r = await fetch(`/api/conversas/${conversaId}/ajuda`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contexto, tom }),
    }).then((x) => x.json()).catch(() => null);
    setPensando(false);
    if (r?.ok) {
      // guarda o texto como veio, para o "desfazer edição"
      setOpcoes((r.opcoes || []).map((o: any) => ({ ...o, original: o.texto })));
    }
    else recado.erro(r?.erro === "teto_ia_atingido" ? "Teto de IA do dia atingido." : "Não consegui sugerir agora.");
  }

  if (!aberto) {
    return (
      <button style={{ ...painel.botaoSec, marginBottom: 12 }} onClick={() => setAberto(true)}>
        ✍️ Me ajuda a escrever
      </button>
    );
  }

  return (
    <div style={{ ...painel.card, borderLeft: `4px solid ${cor.teal}`, background: "#f0fdfa" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <strong style={{ color: cor.navy }}>Me ajuda a escrever</strong>
        <button style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer",
                         color: cor.cinza }} onClick={() => setAberto(false)}>✕</button>
      </div>

      <div style={{ marginTop: 10 }}>
        <label style={painel.rotulo}>
          O que você quer dizer? (quanto mais contexto, melhor a sugestão)
        </label>
        <textarea
          style={{ ...painel.input, minHeight: 160, fontFamily: "inherit" }}
          value={contexto}
          onChange={(e) => setContexto(e.target.value)}
          placeholder="Ex.: ela perguntou se dá para adiar a limpeza de novembro. Dá sim, mas quero aproveitar para combinar o Finados. Ela é antiga de casa e sempre paga certinho."
        />
      </div>

      <div style={{ display: "flex", gap: 8, alignItems: "flex-end", flexWrap: "wrap", marginTop: 10 }}>
        <div>
          <label style={painel.rotulo}>Tom</label>
          <select style={{ ...painel.input, width: 150 }} value={tom} onChange={(e) => setTom(e.target.value)}>
            <option value="acolhedor">Acolhedor</option>
            <option value="objetivo">Objetivo</option>
            <option value="firme">Firme</option>
          </select>
        </div>
        <button style={painel.botao} onClick={pedir} disabled={pensando}>
          {pensando ? "Pensando…" : opcoes.length ? "Sugerir de novo" : "Sugerir 3 caminhos"}
        </button>
      </div>

      {opcoes.map((o, i) => (
        <div key={i} style={{ background: "#fff", border: `1px solid ${cor.linha}`,
                              borderRadius: 10, padding: 12, marginTop: 10 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center",
                        gap: 8, flexWrap: "wrap" }}>
            <div style={{ fontSize: 14, color: cor.teal, textTransform: "uppercase",
                          letterSpacing: 0.5, fontWeight: 700 }}>
              {o.titulo || `Opção ${i + 1}`}
            </div>
            {o.texto !== (o.original ?? o.texto) && (
              <button
                style={{ background: "none", border: "none", color: cor.cinza, fontSize: 13,
                         cursor: "pointer", textDecoration: "underline" }}
                onClick={() => trocarTexto(i, o.original)}
              >
                desfazer edição
              </button>
            )}
          </div>

          {/* editável aqui mesmo: dá para ajustar antes de escolher */}
          <textarea
            style={{ ...painel.input, minHeight: 130, marginTop: 8, fontFamily: "inherit",
                     lineHeight: 1.5, resize: "vertical" }}
            value={o.texto}
            onChange={(e) => trocarTexto(i, e.target.value)}
          />

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8, alignItems: "center" }}>
            <button style={painel.botao}
                    onClick={() => { onEscolher(o.texto); setAberto(false); }}>
              Usar esta
            </button>
            <button style={painel.botaoSec}
                    onClick={() => { navigator.clipboard?.writeText(o.texto); setCopiado(i);
                                     setTimeout(() => setCopiado(null), 1500); }}>
              {copiado === i ? "✓ copiado" : "Copiar"}
            </button>
            <span style={{ fontSize: 13, color: cor.cinza }}>
              {o.texto.trim().split(/\s+/).filter(Boolean).length} palavras
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
