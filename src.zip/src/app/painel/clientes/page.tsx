"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { PainelNav, painel, cor, numeroBR } from "../ui";
import { Falhou } from "../pecas";
import { ATALHOS_FREQUENCIA } from "@/lib/frequencia";
import VisaoJazigos from "./VisaoJazigos";
import VincularLote from "./VincularLote";
import CadastrarFamilia from "./CadastrarFamilia";
import { useConfirmar, useRecado } from "@/components/Dialogos";

/**
 * CARTEIRA — familia, jazigo e servico na MESMA tela.
 *
 * Eram duas telas ("Familias" e "Gestao") e um caminho que nao existia (o que a
 * equipe captura no campo). Nao havia razao para a separacao: se tem familia,
 * tem jazigo, e se tem jazigo, tem servico — e quem trabalha precisa dos tres
 * ao mesmo tempo. Agora sao abas:
 *
 *   Familias        · quem paga, quanto deve, quando lava (a lista de sempre)
 *   Jazigos e planos· cada jazigo com valor, periodicidade e vencimento (a
 *                     antiga "Gestao", em VisaoJazigos.tsx)
 *   Do campo (n)    · os jazigos capturados no cemiterio esperando familia
 *
 * A aba fica no endereco (?aba=jazigos): dá para mandar o link certo para
 * alguem e o F5 nao joga a pessoa de volta para a primeira aba. A leitura e
 * feita no window (dentro do useEffect), NAO com useSearchParams — que no
 * Next 14 obriga um <Suspense> em volta da pagina inteira so por causa disso.
 */
type Aba = "familias" | "jazigos" | "campo";

const ABAS: { chave: Aba; rotulo: string }[] = [
  { chave: "familias", rotulo: "Famílias" },
  { chave: "jazigos", rotulo: "Jazigos e planos" },
  // A aba "Mapa" saiu: a navegação da Nina é a plaquinha na pedra mais o
  // endereço (quadra + rua), e o mapa com pinos foi desligado. Mantê-la aqui
  // deixava a tela desligada acessível por uma porta lateral.
  { chave: "campo", rotulo: "Do campo" },
];

export default function Carteira() {
  const [aba, setAba] = useState<Aba>("familias");
  const [orfaos, setOrfaos] = useState<number | null>(null);

  useEffect(() => {
    const q = new URLSearchParams(window.location.search).get("aba");
    if (ABAS.some((a) => a.chave === q)) setAba(q as Aba);
  }, []);

  // contador da aba "Do campo": o numero e o convite. Sem ele ninguem descobre
  // que ha jazigo esperando familia — foi assim que a fila cresceu ate agora.
  const contarOrfaos = useCallback(() => {
    fetch("/api/tumulos")
      .then((x) => x.json())
      .then((r) => { if (r?.ok) setOrfaos((r.semDono || []).length); })
      .catch(() => {});
  }, []);
  useEffect(() => { contarOrfaos(); }, [contarOrfaos]);

  function trocar(a: Aba) {
    setAba(a);
    const url = a === "familias" ? "/painel/clientes" : `/painel/clientes?aba=${a}`;
    window.history.replaceState(null, "", url);
  }

  return (
    <div style={painel.wrap}>
      <PainelNav atual="/painel/clientes" />
      <div style={painel.conteudo}>
        <h1 style={{ ...painel.h1, marginBottom: 10 }}>Famílias</h1>

        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
          {ABAS.map((a) => {
            const ativa = aba === a.chave;
            const n = a.chave === "campo" ? orfaos : null;
            return (
              <button
                key={a.chave}
                onClick={() => trocar(a.chave)}
                style={{
                  ...(ativa ? painel.botaoMini : painel.botaoMiniSec),
                  ...(a.chave === "campo" && !ativa && n ? { borderColor: "rgb(var(--zm-aviso))", color: "rgb(var(--zm-aviso))" } : {}),
                }}
              >
                {a.rotulo}{n ? ` (${n})` : ""}
              </button>
            );
          })}
        </div>

        {aba === "familias" && <VisaoFamilias />}
        {aba === "jazigos" && <VisaoJazigos />}
        {aba === "campo" && <VincularLote onMudou={contarOrfaos} />}
      </div>
    </div>
  );
}

interface Cli {
  id: string;
  nome: string;
  telefone: string;
  modo: string;
  score: number;
  ativo_ia: boolean;
}

function VisaoFamilias() {
  const recado = useRecado();
  const perguntar = useConfirmar();
  const [d, setD] = useState<any>(null);
  const [f, setF] = useState({ busca: "", quadra: "", rua: "", cadencia: "", situacao: "",
                               regua: "", venceEm: "", ordem: "nome", teste: false, etapa: "" });

  /**
   * O ATALHO CHEGA PELO ENDEREÇO.
   *
   * O funil do Financeiro tem uma etapa — "a receber" — que não se resolve lá:
   * resolve-se aqui, família por família. Sem isto, o clique traria a lista
   * inteira e a pessoa teria de refazer o filtro à mão, que é exatamente o que
   * o funil existe para evitar.
   */
  useEffect(() => {
    const a = new URLSearchParams(window.location.search).get("atalho");
    if (a === "em_aberto") setF((x) => ({ ...x, situacao: "atrasados", ordem: "saldo" }));
    if (a === "incompleto") setF((x) => ({ ...x, etapa: "sem_tumulo" }));
    if (a === "proxima_lavagem") setF((x) => ({ ...x, ordem: "lavagem" }));
  }, []);
  const [quadras, setQuadras] = useState<any[]>([]);
  // DUAS TAREFAS DIFERENTES, DUAS PORTAS (CA-05).
  // "Nova família / importar" era um botão só que abria um cartão com duas
  // abas: o cadastro do atendimento por telefone e a colagem de uma planilha.
  // São trabalhos de momentos opostos — um é com a família na linha, o outro é
  // uma migração feita uma vez. Dividir a mesma área entre os dois fazia a
  // planilha aparecer quando ela queria cadastrar uma senhora.
  const [abrindo, setAbrindo] = useState<null | "nova" | "csv">(null);
  /** As famílias marcadas para a ação em lote. Guarda o id da FAMÍLIA. */
  const [marcadas, setMarcadas] = useState<Set<string>>(new Set());
  const [excluindo, setExcluindo] = useState(false);

  /**
   * EXCLUIR AS MARCADAS.
   *
   * Nasceu das 97 duplicadas: "Família Cemitério" sozinha aparece ~30 vezes.
   * Abrir 30 fichas para apagar 30 cascas é o trabalho que o lote tira.
   *
   * Usa a MESMA porta da ficha — a que recusa quem não está vazia e diz o que
   * está preso. Um lote que apagasse à força levaria jazigos junto, e é
   * exatamente o desenho que já mordeu esta casa uma vez.
   *
   * O relatório do fim é o ponto: diz quantas saíram e, para cada recusada, o
   * motivo. Sem ele, "excluí 30 e sumiram 12" seria um mistério.
   */
  async function excluirMarcadas() {
    const alvos = [...marcadas];
    if (!alvos.length) return;
    if (!await perguntar({
      oQue: `Excluir ${alvos.length} ${alvos.length === 1 ? "família" : "famílias"}?`,
      efeito: "Só saem as que estiverem VAZIAS — sem contato, sem jazigo e sem lançamento. "
            + "As demais continuam onde estão, e eu digo o motivo de cada uma.",
      confirmar: "Excluir as vazias", tom: "perigo",
    })) return;

    setExcluindo(true);
    const recusadas: string[] = [];
    let saíram = 0;
    try {
      for (const id of alvos) {
        const r = await fetch(`/api/familias/${id}`, { method: "DELETE" })
          .then((x) => x.json()).catch(() => null);
        if (r?.ok) saíram++;
        else {
          const nome = (d?.clientes || []).find((c: any) => c.familia_id === id)?.familia || id.slice(0, 8);
          recusadas.push(`${nome}: ${r?.mensagem || "não deu"}`);
        }
      }
    } finally { setExcluindo(false); }

    setMarcadas(new Set());
    await carregar();
    recado.ok(
      `${saíram} ${saíram === 1 ? "família excluída" : "famílias excluídas"}.`
      + (recusadas.length
          ? `\n\nNão saíram (${recusadas.length}):\n` + recusadas.slice(0, 10).join("\n")
            + (recusadas.length > 10 ? `\n…e mais ${recusadas.length - 10}.` : "")
            + `\n\nPara duplicadas com jazigo ou contato, abra a ficha e use "Fundir com outra família".`
          : ""));
  }

  const [erroLista, setErroLista] = useState("");

  const carregar = useCallback(async () => {
    const p = new URLSearchParams();
    Object.entries(f).forEach(([k, v]) => {
      if (k === "teste") { if (v) p.set("teste", "1"); }
      else if (v) p.set(k, String(v));
    });
    try {
      const x = await fetch(`/api/clientes?${p}`);
      if (!x.ok) throw new Error(`HTTP ${x.status}`);
      const r = await x.json();
      if (!r?.ok) throw new Error(r?.erro || "resposta_negativa");
      setD(r);
      setErroLista("");
    } catch (e) {
      // Com `catch(() => null)` e `if (r?.ok)`, uma falha deixava `d` nulo para
      // sempre e a tela ficava presa em "Carregando…" — sem erro, sem botao,
      // sem nada a fazer alem de recarregar a pagina no chute.
      console.error("[familias] carregar:", e);
      setErroLista("Não consegui carregar a lista de famílias.");
    }
  }, [f]);

  useEffect(() => { carregar(); }, [carregar]);
  useEffect(() => {
    fetch("/api/quadras").then((x) => x.json()).then((r) => r.ok && setQuadras(r.quadras)).catch(() => {});
  }, []);

  // ABRE SOZINHO QUANDO ALGUM ESTÁ EM USO. Filtro escondido e ativo é a
  // lista curta sem explicação — e a pessoa procurando a família que "sumiu".
  const temFiltroAvancado = !!(f.quadra || f.rua || f.cadencia || f.venceEm || f.teste
    || f.regua || (f.ordem && f.ordem !== "nome") || f.situacao || f.etapa);

  const ruas = d ? [...new Set(d.clientes.flatMap((c: any) => c.ruas))].sort() : [];
  const money = (n: number) => `R$ ${Number(n || 0).toFixed(2)}`;

  return (
    <div>
      <div>
        <div style={{ ...painel.card, padding: 12 }}>
          {/* AS ETAPAS DO CADASTRO.
              São 66 famílias e o trabalho é feito aos poucos: ligar o túmulo,
              preencher o contrato, começar a registrar limpeza. Sem isto, a
              Sureya reabre as mesmas fichas para descobrir que já fez — e as
              que faltam somem no meio.
              A etapa é derivada dos dados: um "já conferi" marcado à mão
              desatualiza no dia em que alguém mexe por outro caminho. */}
          {d?.porEtapa && (
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 10 }}>
              {([
                ["", "Todas", null],
                ["sem_tumulo", "Sem túmulo", d.porEtapa.sem_tumulo],
                ["sem_contrato", "Falta contrato", d.porEtapa.sem_contrato],
                ["pronta", "Pronta, sem limpeza", d.porEtapa.pronta],
                ["operacional", "Operacional", d.porEtapa.operacional],
              ] as [string, string, number | null][]).map(([v, rot, n]) => (
                <button
                  key={v || "todas"}
                  onClick={() => setF({ ...f, etapa: v })}
                  style={f.etapa === v ? painel.botaoMini : painel.botaoMiniSec}
                >
                  {rot}{n !== null ? ` (${n})` : ""}
                </button>
              ))}
            </div>
          )}

          {/* A CONSULTA DO DIA A DIA, E SÓ ELA (CA-04).
              Antes da lista havia três abas, cinco etapas, busca, situação,
              quadra, rua, periodicidade, vencimento, ordenação, teste e limpar
              — uma central de filtros para atravessar toda vez que a pergunta
              era "quem está devendo?". No celular os selects viravam carrossel
              horizontal e metade ficava fora da vista.

              Os filtros NÃO SAÍRAM: eles servem, e quem monta uma cobrança por
              quadra precisa deles. Só desceram para "Mais filtros", que fica
              aberto sozinho quando algum está em uso — senão a pessoa filtra,
              recolhe, e depois não entende por que a lista está curta. */}
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 8 }}>
            <input style={{ ...painel.input, flex: 1, minWidth: 200 }} value={f.busca}
                   onChange={(e) => setF({ ...f, busca: e.target.value })}
                   placeholder="Buscar por nome, telefone ou jazigo…" />
            {([
              ["Em aberto", { situacao: "atrasados", ordem: "saldo" }],
              ["Cadastro incompleto", { etapa: "sem_tumulo", situacao: "" }],
              ["Próxima lavagem", { situacao: "", ordem: "lavagem" }],
            ] as [string, any][]).map(([rot, alvo]) => {
              const ligado = Object.entries(alvo).every(([k, v]) => (f as any)[k] === v);
              return (
                <button
                  key={rot}
                  style={ligado ? painel.botaoMini : painel.botaoMiniSec}
                  onClick={() => setF(ligado
                    ? { ...f, situacao: "", etapa: "", ordem: "nome" }
                    : { ...f, situacao: "", etapa: "", ordem: "nome", ...alvo })}
                >
                  {rot}
                </button>
              );
            })}
          </div>

          <details open={temFiltroAvancado} style={{ marginBottom: 4 }}>
            <summary style={{ cursor: "pointer", fontSize: 14, color: cor.cinza, padding: "6px 0" }}>
              Mais filtros{temFiltroAvancado ? " (em uso)" : ""}
            </summary>
          <div data-filtros style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", paddingTop: 8 }}>
            <select style={{ ...painel.input, width: "auto" }} value={f.situacao}
                    onChange={(e) => setF({ ...f, situacao: e.target.value })}>
              <option value="">Todas as situações</option>
              <option value="atrasados">A receber</option>
              <option value="em_dia">Em dia</option>
              <option value="adiantados">Adiantados</option>
              <option value="automatico">IA no automático</option>
              <option value="ia_desligada">IA desligada</option>
              <option value="envio_desligado">Envio automático desligado</option>
              <option value="sem_telefone">Sem telefone</option>
              <option value="falta_data">Falta data de lavagem ou cobrança</option>
              <option value="nao_conferido">Ainda não conferidos</option>
            </select>
            <select style={{ ...painel.input, width: "auto" }} value={f.quadra}
                    onChange={(e) => setF({ ...f, quadra: e.target.value, rua: "" })}>
              <option value="">Todas as quadras</option>
              {quadras.map((q) => <option key={q.id} value={q.codigo}>{q.codigo}</option>)}
            </select>
            <select style={{ ...painel.input, width: "auto" }} value={f.rua}
                    onChange={(e) => setF({ ...f, rua: e.target.value })}>
              <option value="">Todas as ruas</option>
              {ruas.map((r: any) => <option key={r} value={r}>{r}</option>)}
            </select>
            <select style={{ ...painel.input, width: "auto" }} value={f.cadencia}
                    onChange={(e) => setF({ ...f, cadencia: e.target.value })}>
              <option value="">Toda periodicidade</option>
              {/* Faltavam "semanal" e "quinzenal", que existem no enum desde
                  sempre e são os ritmos mais usados no cemitério — filtrar por
                  eles era impossível. */}
              {["semanal","quinzenal","mensal","bimestral","trimestral","semestral","anual","avulso"].map((c) =>
                <option key={c} value={c}>{c}</option>)}
            </select>
            <select style={{ ...painel.input, width: "auto" }} value={f.venceEm}
                    onChange={(e) => setF({ ...f, venceEm: e.target.value })}>
              <option value="">Qualquer vencimento</option>
              <option value="7">Vence em 7 dias</option>
              <option value="15">Vence em 15 dias</option>
              <option value="30">Vence em 30 dias</option>
            </select>
            <select style={{ ...painel.input, width: "auto" }} value={f.ordem}
                    onChange={(e) => setF({ ...f, ordem: e.target.value })}>
              <option value="nome">Ordenar por nome</option>
              <option value="saldo">Quem deve mais</option>
              <option value="valor">Maior valor por limpeza</option>
              <option value="lavagem">Próxima lavagem</option>
              <option value="cobranca">Próxima cobrança</option>
            </select>
            <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 15, color: cor.cinza }}>
              <input type="checkbox" checked={f.teste}
                     onChange={(e) => setF({ ...f, teste: e.target.checked })} /> teste
            </label>
            <button style={painel.botaoSec}
                    onClick={() => setF({ busca: "", quadra: "", rua: "", cadencia: "", situacao: "",
                                          regua: "", venceEm: "", ordem: "nome", teste: false, etapa: "" })}>
              Limpar
            </button>
          </div>
          </details>
        </div>

        {d && (
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 14, color: cor.cinza, fontSize: 14 }}>
            <span><b style={{ color: cor.navy }}>{d.totais.quantidade}</b> famílias</span>
            <span><b style={{ color: cor.navy }}>{money(d.totais.mensal)}</b> por mês</span>
            <span><b style={{ color: d.totais.atrasados ? "rgb(var(--zm-perigo))" : cor.teal }}>
              {d.totais.atrasados}</b> a receber ({money(d.totais.emAberto)})</span>
            {d.totais.faltaData > 0 && (
              <span style={{ color: "rgb(var(--zm-aviso))" }}>
                <b>{d.totais.faltaData}</b> sem data de lavagem ou cobrança
              </span>
            )}
            <button style={{ ...painel.botao, marginLeft: "auto" }}
                    onClick={() => setAbrindo(abrindo === "nova" ? null : "nova")}>
              {abrindo === "nova" ? "Fechar" : "+ Nova família"}
            </button>
            <button style={painel.botaoSec}
                    onClick={() => setAbrindo(abrindo === "csv" ? null : "csv")}>
              {abrindo === "csv" ? "Fechar" : "Importar planilha"}
            </button>
          </div>
        )}

        {abrindo === "nova" && (
          <CadastrarFamilia
            onPronto={() => { setAbrindo(null); carregar(); }}
            onCancelar={() => setAbrindo(null)}
          />
        )}
        {abrindo === "csv" && <Importar onPronto={() => { setAbrindo(null); carregar(); }} />}

        {!!erroLista && <Falhou mensagem={erroLista} aoTentar={carregar} parcial={!!d} />}
        {!d && !erroLista && <p style={{ color: cor.cinza }}>Carregando…</p>}
        {d && d.clientes.length === 0 && (
          <div style={painel.card}><p style={{ color: cor.cinza, margin: 0 }}>Nenhuma família com esses filtros.</p></div>
        )}

        {/* A BARRA DE LOTE. Só aparece com alguém marcado: uma barra vazia
            permanente é ruído em cima da lista que se usa todo dia. */}
        {marcadas.size > 0 && (
          <div style={{ ...painel.card, display: "flex", flexWrap: "wrap", gap: 10,
                        alignItems: "center", position: "sticky", top: 8, zIndex: 5 }}>
            <b style={{ color: cor.navy }}>
              {marcadas.size} {marcadas.size === 1 ? "família marcada" : "famílias marcadas"}
            </b>
            <button style={painel.botaoMiniSec} onClick={() => setMarcadas(new Set())}>
              Desmarcar
            </button>
            <span style={{ flex: 1 }} />
            <button style={{ ...painel.botaoMini, background: "rgb(var(--zm-perigo))" }}
                    disabled={excluindo} onClick={excluirMarcadas}>
              {excluindo ? "Excluindo…" : `Excluir ${marcadas.size}`}
            </button>
          </div>
        )}

        {d && d.clientes.map((c: any) => (
          <Link key={c.id} href={`/painel/clientes/${c.id}`} style={{ textDecoration: "none" }}>
            <div style={{ ...painel.card, borderLeft: c.atrasado ? "4px solid #dc2626" : `1px solid ${cor.linha}` }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
                {/* O SELECT NA FRENTE.
                    `preventDefault` porque a linha inteira é um link: sem ele,
                    marcar a caixa abriria a ficha e a marcação se perderia. */}
                {c.familia_id && (
                  <input
                    type="checkbox"
                    checked={marcadas.has(c.familia_id)}
                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
                    onChange={() => {}}
                    onMouseDown={(e) => {
                      e.preventDefault(); e.stopPropagation();
                      setMarcadas((m) => {
                        const n = new Set(m);
                        if (n.has(c.familia_id)) n.delete(c.familia_id); else n.add(c.familia_id);
                        return n;
                      });
                    }}
                    style={{ width: 18, height: 18, marginTop: 3, flexShrink: 0, cursor: "pointer" }}
                    title="Marcar para a ação em lote"
                  />
                )}
                <div style={{ flex: 1, minWidth: 200 }}>
                  {/* FAMÍLIA E RESPONSÁVEL, antes de abrir a ficha.
                      A lista mostrava só o nome da PESSOA — e a família
                      costuma se chamar de outro jeito. Procurar "Alcantara"
                      não achava nada quando o contato se chama "Clecia". */}
                  <strong style={{ color: cor.navy, fontSize: 16 }}>
                    (Família - {c.familia || c.nome})
                  </strong>
                  <div style={{ fontSize: 15, color: cor.cinza, marginTop: 2 }}>
                    (Responsável - {c.nome})
                    {!c.ehResponsavel && (
                      <span style={{ color: "rgb(var(--zm-aviso))" }}>
                        {" "}· esta pessoa não é quem acerta a conta
                      </span>
                    )}
                  </div>
                  {/* A ETAPA, ao lado do nome. Ela diz qual é o PRÓXIMO passo
                      daquela família — e não só um rótulo de estado. Quem abre
                      a lista para trabalhar precisa saber onde continuar. */}
                  {/* O SELO DIZ A TAREFA, e vem da mesma conta da ficha (0106).
                      "iniciar controle" aparecia numa família conferida, com
                      contrato completo — porque esta lista fazia a própria
                      conta, olhando campos que a D-24 esvaziou. Agora o texto
                      vem de `falta`, que é o próximo passo em português. */}
                  {c.etapa && c.etapa !== "operacional" && (
                    <span style={{
                      marginLeft: 8, borderRadius: 999, padding: "2px 9px", fontSize: 12,
                      fontWeight: 600, whiteSpace: "nowrap",
                      background: c.etapa === "pronta"
                        ? "rgb(var(--zm-teal) / 0.12)" : "rgb(var(--zm-aviso) / 0.12)",
                      color: c.etapa === "pronta" ? cor.teal : "rgb(var(--zm-aviso))",
                    }}>
                      {c.etapa === "pronta" ? "aguardando a 1ª limpeza"
                        : c.falta || (c.etapa === "sem_tumulo" ? "ligar o túmulo" : "completar o contrato")}
                    </span>
                  )}
                  {/* Quem já recebeu o ok da conferência não pode parecer
                      pendente: era a contradição que o usuário viu na tela. */}
                  {c.conferidaEm && (
                    <span style={{
                      marginLeft: 6, borderRadius: 999, padding: "2px 9px", fontSize: 12,
                      fontWeight: 600, whiteSpace: "nowrap",
                      background: "rgb(var(--zm-teal) / 0.12)", color: cor.teal,
                    }}>
                      conferida
                    </span>
                  )}
                  <div style={{ fontSize: 15, color: cor.cinza, marginTop: 3 }}>
                    {(c.jazigos || []).map((j: any) => `${j.id}${j.quadra ? ` (${j.quadra}${j.rua ? " · " + j.rua : ""})` : ""}`).join(" + ") || "sem jazigo"}
                  </div>
                  <div style={{ fontSize: 15, color: cor.cinza, marginTop: 3 }}>
                    {(c.cadenciasRotulo || []).join(", ") || "sem ritmo definido"}
                    {c.mensal > 0 && ` · ${money(c.mensal)}/mês`}
                    {c.modo === "automatico" && " · IA automática"}
                    {!c.ativo_ia && " · IA desligada"}
                    {c.envio_automatico === false && (
                      <span style={{ color: "rgb(var(--zm-aviso))", fontWeight: 600 }}> · em revisão (não envia)</span>
                    )}
                  </div>
                  <div style={{ fontSize: 15, marginTop: 3,
                                color: c.faltaData ? "rgb(var(--zm-aviso))" : cor.cinza }}>
                    {c.proximaLavagem
                      ? `Lava em ${new Date(c.proximaLavagem + "T12:00:00").toLocaleDateString("pt-BR")}`
                      : "Sem data de lavagem"}
                    {" · "}
                    {c.proximaCobranca
                      ? `Cobra em ${new Date(c.proximaCobranca + "T12:00:00").toLocaleDateString("pt-BR")}`
                      : "Sem data de cobrança"}
                    {c.faltaData && " ← falta preencher"}
                  </div>
                </div>
                {/* O NUMERO E O MESMO QUE DECIDE O `atrasado` (0114): `vencido`.
                    Mostrar `saldo` aqui e marcar em vermelho pelo vencido
                    poria a lista a discordar de si mesma na mesma linha. */}
                <div style={{ textAlign: "right" }}>
                  <b style={{ color: c.atrasado ? "rgb(var(--zm-perigo))" : c.vencido > 0 ? cor.teal : cor.cinza, fontSize: 16 }}>
                    {Math.abs(c.vencido) < 0.005 ? "em dia" : money(Math.abs(c.vencido))}
                  </b>
                  <div style={{ fontSize: 14, color: cor.cinza }}>
                    {c.atrasado ? "a receber" : c.vencido > 0 ? "a favor dela" : ""}
                  </div>
                  {/* Prestado e ainda nao vencido: nem divida, nem invisivel. */}
                  {c.aVencer > 0.005 && (
                    <div style={{ fontSize: 13, color: cor.cinza }}>
                      {money(c.aVencer)} a vencer
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}


/**
 * IMPORTAR PLANILHA — só isto.
 *
 * Este componente carregava DUAS tarefas: o cadastro de uma família durante a
 * ligação e a colagem de uma planilha inteira. Elas dividiam a mesma área com
 * duas abas, e são de momentos opostos — uma é com a família na linha, a outra
 * é uma migração que se faz uma vez. O cadastro saiu para
 * `CadastrarFamilia.tsx`, em quatro passos (CA-05).
 */
function Importar({ onPronto }: { onPronto: () => void }) {
  const recado = useRecado();
  const [csv, setCsv] = useState("");
  const [ocupado, setOcupado] = useState(false);

  async function importar() {
    if (!csv.trim()) return;
    setOcupado(true);
    const r = await fetch("/api/tumulos/importar", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ csv }),
    }).then((x) => x.json()).catch(() => null);
    setOcupado(false);
    if (!r?.ok) { recado.erro("Falhou: " + (r?.erro || "erro")); return; }
    // r.criados e um objeto {clientes, tumulos, planos} — o alert antigo escrevia
    // "[object Object] linha(s)". E r.erros, que e onde moram TODAS as linhas
    // recusadas (valor ilegivel, jazigo de outra familia, duplicata), nao
    // aparecia em lugar nenhum: 45 familias podiam ficar de fora e a tela dizia
    // "pronto".
    const c = r.criados || {};
    const partes = [
      `${c.clientes || 0} familia(s)`,
      `${c.tumulos || 0} jazigo(s)`,
      `${c.planos || 0} plano(s)`,
    ].join(", ");
    const erros: { linha: number; motivo: string }[] = r.erros || [];
    if (erros.length) {
      const lista = erros.slice(0, 20).map((e) => `linha ${e.linha}: ${e.motivo}`).join("\n");
      const resto = erros.length > 20 ? `\n… e mais ${erros.length - 20} linha(s).` : "";
      // AVISO, e nao recibo verde: entrou pela metade.
      recado.aviso(
        `Importado: ${partes}.\n\n${erros.length} linha(s) NAO entraram:\n\n${lista}${resto}` +
        "\n\nCorrija essas linhas na planilha e importe so elas de novo."
      );
    } else {
      recado.ok(`Importado: ${partes}.`);
    }
    onPronto();
  }

  return (
    <div style={painel.card}>
      <label style={painel.rotulo}>
        Cole a planilha COM a linha de cabeçalho
      </label>
      {/* o rotulo antigo anunciava uma ordem de colunas que a API nao aceita
          (e sem cabecalho); quem seguia a tela levava erro de cabecalho. */}
      <textarea style={{ ...painel.input, minHeight: 140, fontFamily: "monospace", fontSize: 15 }}
                value={csv} onChange={(e) => setCsv(e.target.value)}
                placeholder={"quadra;identificacao;falecido;cliente_nome;telefone;cadencia;qtd;valor\nQD 1;128;JOSE SILVA;MARIA SILVA;11999998888;mensal;1;40,00"} />
      <p style={{ fontSize: 13, color: cor.cinza, margin: "6px 0 0" }}>
        Obrigatórias: <b>quadra, identificacao, cliente_nome, telefone</b>. As outras são
        opcionais — sem <b>cadencia</b> o jazigo entra sem plano. Valor em reais (40 ou 40,00);
        valor que o sistema não entender faz a linha ser recusada, nunca vira um preço chutado.
      </p>
      <button style={{ ...painel.botao, marginTop: 10 }} onClick={importar} disabled={ocupado}>
        {ocupado ? "Importando…" : "Importar"}
      </button>
    </div>
  );
}
